package com.gamelens.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * โหมดจับหน้าจอ: อ่านข้อความจากหน้าจอของเครื่องเอง (เกมมือถือ/แอปอื่น)
 * แล้ววาดคำแปลทับบนหน้าจอ โดยไม่ต้องใช้ Capture Card
 */
class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.gamelens.app.START_SCREEN"
        const val ACTION_STOP = "com.gamelens.app.STOP_SCREEN"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CHANNEL_ID = "switfire_screen"
        private const val NOTIFICATION_ID = 4321

        @Volatile
        var isRunning = false
            private set
    }

    private lateinit var settings: AppSettings
    private val ocr = OcrEngine()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: ScreenOverlay? = null
    private var loop: Job? = null
    private var frameBitmap: Bitmap? = null

    private val stabilizers = HashMap<String, TextStabilizer>()
    private val cache = HashMap<String, String>()
    private var screenWidth = 0
    private var screenHeight = 0

    @Volatile private var paused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopEverything()
            return START_NOT_STICKY
        }
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val resultData: Intent? = intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundNotification()
        startCapture(resultCode, resultData)
        return START_STICKY
    }

    // ---------- แจ้งเตือนค้างไว้ (ระบบบังคับสำหรับการจับหน้าจอ) ----------

    private fun startForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID, "โหมดจับหน้าจอ", NotificationManager.IMPORTANCE_LOW
        )
        manager.createNotificationChannel(channel)

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("SwitFire กำลังแปลหน้าจอ")
            .setContentText("แตะเพื่อหยุด")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(stopIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    // ---------- จับภาพหน้าจอ ----------

    private fun startCapture(resultCode: Int, resultData: Intent) {
        val manager = getSystemService(MediaProjectionManager::class.java)
        val projection = manager.getMediaProjection(resultCode, resultData) ?: run {
            stopSelf()
            return
        }
        this.projection = projection
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopEverything()
            }
        }, main)

        val metrics = screenMetrics()
        screenWidth = metrics.first
        screenHeight = metrics.second
        val density = resources.displayMetrics.densityDpi

        val imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        reader = imageReader
        virtualDisplay = projection.createVirtualDisplay(
            "SwitFire", screenWidth, screenHeight, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface, null, null,
        )

        overlay = ScreenOverlay(
            context = this,
            settings = settings,
            onAddRegion = { rect -> addRegion(rect) },
            onTogglePause = {
                paused = !paused
                paused
            },
            onDeleteLast = { deleteLastRegion() },
            onStop = { stopEverything() },
        ).also { it.show(screenWidth, screenHeight) }

        isRunning = true
        startLoop()
    }

    private fun screenMetrics(): Pair<Int, Int> {
        val windowManager = getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            @Suppress("DEPRECATION")
            val metrics = DisplayMetrics().also { windowManager.defaultDisplay.getRealMetrics(it) }
            metrics.widthPixels to metrics.heightPixels
        }
    }

    // ---------- วนอ่านข้อความและแปล ----------

    private fun startLoop() {
        loop?.cancel()
        loop = scope.launch {
            while (isActive) {
                val interval = (settings.ocrInterval * 1000).toLong().coerceAtLeast(250)
                delay(interval)
                if (paused) continue
                val regions = settings.screenRegions.filter { it.enabled }
                if (regions.isEmpty()) continue
                val frame = grabFrame() ?: continue
                for (region in regions) {
                    runCatching { process(region, frame) }
                }
            }
        }
    }

    private fun grabFrame(): Bitmap? {
        val image = reader?.acquireLatestImage() ?: return null
        return try {
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val width = if (pixelStride > 0) rowStride / pixelStride else image.width
            var bitmap = frameBitmap
            if (bitmap == null || bitmap.width != width || bitmap.height != image.height) {
                bitmap?.recycle()
                bitmap = Bitmap.createBitmap(width, image.height, Bitmap.Config.ARGB_8888)
                frameBitmap = bitmap
            }
            plane.buffer.rewind()
            bitmap.copyPixelsFromBuffer(plane.buffer)
            bitmap
        } catch (e: Exception) {
            null
        } finally {
            image.close()
        }
    }

    private suspend fun process(region: Region, frame: Bitmap) {
        val left = (region.rect.x * screenWidth).toInt().coerceIn(0, frame.width - 2)
        val top = (region.rect.y * screenHeight).toInt().coerceIn(0, frame.height - 2)
        val width = (region.rect.w * screenWidth).toInt().coerceAtMost(frame.width - left)
        val height = (region.rect.h * screenHeight).toInt().coerceAtMost(frame.height - top)
        if (width < 16 || height < 16) return

        val crop = Bitmap.createBitmap(frame, left, top, width, height)
        val text = try {
            ocr.recognizeWholeBitmap(crop, settings.sourceLanguage)
        } finally {
            crop.recycle()
        }

        val stabilizer = stabilizers.getOrPut(region.id) { TextStabilizer() }
        stabilizer.requiredStableCount = settings.stableFrames
        when (val event = stabilizer.feed(text)) {
            is TextStabilizer.Event.None -> Unit
            is TextStabilizer.Event.Cleared ->
                if (settings.hideWhenNoText) overlay?.clearResult(region.id)
            is TextStabilizer.Event.NewText -> translate(region, event.text)
        }
    }

    private suspend fun translate(region: Region, text: String) {
        val source = settings.sourceLanguage
        val target = settings.targetLanguage
        if (source.id == target.id) {
            overlay?.setResult(region, text, text)
            return
        }
        val key = "${settings.engine.name}|${source.id}|${target.id}|$text"
        cache[key]?.let {
            overlay?.setResult(region, text, it)
            return
        }
        overlay?.setResult(region, text, "กำลังแปล…")
        val translated = try {
            SharedTranslate.translate(settings, text, source, target)
        } catch (e: Exception) {
            "⚠️ ${e.message ?: "แปลไม่สำเร็จ"}"
        }
        if (cache.size > 300) cache.clear()
        cache[key] = translated
        overlay?.setResult(region, text, translated)
    }

    // ---------- จัดการกรอบ ----------

    private fun addRegion(rect: NormRect) {
        val number = settings.screenRegions.size + 1
        settings.addScreenRegion(
            Region(
                name = "กรอบ $number",
                rect = rect,
                fontSize = settings.fontSize,
                colorIndex = (number - 1) % AppSettings.palette.size,
                showOriginal = settings.showOriginal,
                overlayPosition = settings.overlayPosition,
            )
        )
    }

    private fun deleteLastRegion() {
        val last = settings.screenRegions.lastOrNull() ?: return
        settings.removeScreenRegion(last.id)
        stabilizers.remove(last.id)
        overlay?.clearResult(last.id)
    }

    // ---------- หยุดการทำงาน ----------

    private fun stopEverything() {
        isRunning = false
        loop?.cancel()
        overlay?.hide()
        overlay = null
        runCatching { virtualDisplay?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        virtualDisplay = null
        reader = null
        projection = null
        frameBitmap?.recycle()
        frameBitmap = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        isRunning = false
        loop?.cancel()
        scope.coroutineContext[Job]?.cancel()
        overlay?.hide()
        super.onDestroy()
    }
}
