package com.gamelens.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** การตั้งค่าทั้งหมด (บันทึกอัตโนมัติ และ UI อัปเดตตามทันที) */
class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("gamelens", Context.MODE_PRIVATE)

    /** เรียกทุกครั้งที่ค่าเปลี่ยน */
    var onChange: (() -> Unit)? = null

    var sourceLangId by stringPref("sourceLang", "en")
    var targetLangId by stringPref("targetLang", "th")
    private var engineName by stringPref("engine", TranslationEngine.MLKIT.name)
    var claudeModel by stringPref("claudeModel", "claude-haiku-4-5-20251001")
    var claudeApiKey by stringPref("claudeKey", "")
    var myMemoryEmail by stringPref("myMemoryEmail", "")
    private var myMemoryUsed by intPref("myMemoryUsed", 0)
    private var myMemoryDate by stringPref("myMemoryDate", "")
    var fallbackToGoogle by boolPref("fallbackToGoogle", true)

    var fontSize by floatPref("fontSize", 24f)
    var opacity by floatPref("opacity", 0.85f)
    var colorIndex by intPref("colorIndex", 0)
    var showOriginal by boolPref("showOriginal", true)
    var showPronunciation by boolPref("showPronunciation", false)
    private var overlayName by stringPref("overlay", OverlayPosition.AUTO.name)

    var ocrInterval by floatPref("ocrInterval", 0.4f)
    var stableFrames by intPref("stableFrames", 2)
    var hideWhenNoText by boolPref("hideWhenNoText", true)

    var audioEnabled by boolPref("audioEnabled", true)
    var audioVolume by floatPref("audioVolume", 1f)

    var subtitleScreenMode by boolPref("subtitleScreen", false)
    var subtitleLines by intPref("subtitleLines", 2)
    /** แสดงกรอบเส้นประรอบบริเวณที่ OCR (ปิดได้หลังตีกรอบเสร็จ) */
    var showRegionOutline by boolPref("showRegionOutline", true)
    /** ความละเอียดสูงสุดที่ขอจาก Capture Card (1080 / 1440 / 2160) */
    var maxResolution by intPref("maxResolution", 1080)
    /** แสดง FPS และข้อมูลตรวจสอบบนจอ */
    var showDiagnostics by boolPref("showDiagnostics", false)
    /** สัดส่วนภาพ: 0 = อัตโนมัติ, 1 = 16:9, 2 = 4:3, 3 = เต็มพื้นที่ */
    var aspectMode by intPref("aspectMode", 0)
    /** โหมดภาพของการ์ดที่เลือกเอง ("" = อัตโนมัติ) */
    var preferredMode by stringPref("preferredMode", "")
    private var roiText by stringPref("roi", "")
    private var regionsJson by stringPref("regions", "")
    private var screenRegionsJson by stringPref("screenRegions", "")

    var engine: TranslationEngine
        get() = TranslationEngine.entries.firstOrNull { it.name == engineName } ?: TranslationEngine.MLKIT
        set(value) { engineName = value.name }

    var overlayPosition: OverlayPosition
        get() = OverlayPosition.entries.firstOrNull { it.name == overlayName } ?: OverlayPosition.AUTO
        set(value) { overlayName = value.name }

    /** กรอบทั้งหมด (แต่ละกรอบตั้งค่าฟอนต์และสีของตัวเองได้) */
    var regions: List<Region>
        get() = Region.listFromJson(regionsJson)
        set(value) { regionsJson = Region.listToJson(value) }

    /** กรอบสำหรับโหมดจับหน้าจอ (พิกัดคนละระบบกับภาพจาก Capture Card) */
    var screenRegions: List<Region>
        get() = Region.listFromJson(screenRegionsJson)
        set(value) { screenRegionsJson = Region.listToJson(value) }

    fun addScreenRegion(region: Region) { screenRegions = screenRegions + region }
    fun removeScreenRegion(id: String) { screenRegions = screenRegions.filter { it.id != id } }
    fun clearScreenRegions() { screenRegions = emptyList() }

    fun addRegion(region: Region) { regions = regions + region }
    fun updateRegion(region: Region) { regions = regions.map { if (it.id == region.id) region else it } }
    fun removeRegion(id: String) { regions = regions.filter { it.id != id } }

    /** ย้ายกรอบเดิม (เวอร์ชันก่อนหน้ามีกรอบเดียว) มาเป็นรายการกรอบ */
    fun migrateLegacyRegion() {
        val legacy = roi ?: return
        if (regions.isEmpty()) {
            addRegion(Region(name = "กรอบ 1", rect = legacy, fontSize = fontSize,
                colorIndex = colorIndex, showOriginal = showOriginal, overlayPosition = overlayPosition))
        }
        roi = null
    }

    var roi: NormRect?
        get() = NormRect.decode(roiText)
        set(value) { roiText = value?.encode() ?: "" }

    val sourceLanguage get() = Languages.find(sourceLangId)
    val targetLanguage get() = Languages.find(targetLangId)
    val textColor get() = palette[colorIndex.coerceIn(0, palette.lastIndex)]

    // ---- โควตา MyMemory (นับเองในเครื่อง เป็นค่าประมาณ) ----

    private val today: String get() = java.time.LocalDate.now().toString()

    /** โควตาต่อวัน: ใส่อีเมล 50,000 ตัวอักษร ไม่ใส่ 5,000 ตัวอักษร */
    val myMemoryLimit: Int get() = if (myMemoryEmail.contains("@")) 50_000 else 5_000

    val myMemoryUsedToday: Int get() = if (myMemoryDate == today) myMemoryUsed else 0

    fun addMyMemoryUsage(chars: Int) {
        if (myMemoryDate != today) {
            myMemoryDate = today
            myMemoryUsed = 0
        }
        myMemoryUsed = myMemoryUsedToday + chars
    }

    fun resetMyMemoryUsage() {
        myMemoryDate = today
        myMemoryUsed = 0
    }

    fun resetAppearance() {
        fontSize = 24f
        opacity = 0.85f
        colorIndex = 0
        showOriginal = true
        showPronunciation = false
        overlayPosition = OverlayPosition.AUTO
    }

    companion object {
        val palette = listOf(
            Color(0xFFFFD142), Color.White, Color(0xFF78E6FF), Color(0xFF8CF299),
            Color(0xFFFF9E4D), Color(0xFFFF738C), Color(0xFFCC99FF),
        )
    }

    // ---- ตัวช่วยเก็บค่า ----

    private fun stringPref(key: String, default: String) = object : ReadWriteProperty<Any?, String> {
        var state by mutableStateOf(prefs.getString(key, default) ?: default)
        override fun getValue(thisRef: Any?, property: KProperty<*>) = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            if (state == value) return
            state = value
            prefs.edit().putString(key, value).apply()
            onChange?.invoke()
        }
    }

    private fun boolPref(key: String, default: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        var state by mutableStateOf(prefs.getBoolean(key, default))
        override fun getValue(thisRef: Any?, property: KProperty<*>) = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            if (state == value) return
            state = value
            prefs.edit().putBoolean(key, value).apply()
            onChange?.invoke()
        }
    }

    private fun intPref(key: String, default: Int) = object : ReadWriteProperty<Any?, Int> {
        var state by mutableStateOf(prefs.getInt(key, default))
        override fun getValue(thisRef: Any?, property: KProperty<*>) = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            if (state == value) return
            state = value
            prefs.edit().putInt(key, value).apply()
            onChange?.invoke()
        }
    }

    private fun floatPref(key: String, default: Float) = object : ReadWriteProperty<Any?, Float> {
        var state by mutableStateOf(prefs.getFloat(key, default))
        override fun getValue(thisRef: Any?, property: KProperty<*>) = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) {
            if (state == value) return
            state = value
            prefs.edit().putFloat(key, value).apply()
            onChange?.invoke()
        }
    }
}
