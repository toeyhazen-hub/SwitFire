package com.gamelens.app

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class TranslationException(message: String) : Exception(message)

// ---------- Google ML Kit (ฟรี ออฟไลน์) ----------

class MlKitTranslate {
    private val translators = mutableMapOf<String, Translator>()
    private val modelManager = RemoteModelManager.getInstance()

    private fun codes(source: GameLanguage, target: GameLanguage): Pair<String, String> {
        val s = source.mlKitCode ?: throw TranslationException("ML Kit ไม่รองรับภาษา ${source.name}")
        val t = target.mlKitCode ?: throw TranslationException("ML Kit ไม่รองรับภาษา ${target.name}")
        return s to t
    }

    private fun client(s: String, t: String): Translator = synchronized(translators) {
        translators.getOrPut("$s>$t") {
            Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(t).build()
            )
        }
    }

    /** ดาวน์โหลดภาษาครบแล้วหรือยัง */
    suspend fun isReady(source: GameLanguage, target: GameLanguage): Boolean = try {
        val (s, t) = codes(source, target)
        listOf(s, t).all { code ->
            modelManager.isModelDownloaded(TranslateRemoteModel.Builder(code).build()).await()
        }
    } catch (e: Exception) {
        false
    }

    suspend fun download(source: GameLanguage, target: GameLanguage) {
        val (s, t) = codes(source, target)
        client(s, t).downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
    }

    suspend fun translate(text: String, source: GameLanguage, target: GameLanguage): String {
        val (s, t) = codes(source, target)
        val c = client(s, t)
        c.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        return c.translate(text).await()
    }
}

// ---------- ตัวช่วย HTTP ----------

private suspend fun httpRequest(
    url: String,
    method: String = "GET",
    headers: Map<String, String> = emptyMap(),
    body: String? = null,
    timeoutMs: Int = 12000,
): Pair<Int, String> = withContext(Dispatchers.IO) {
    val connection = URL(url).openConnection() as HttpURLConnection
    try {
        connection.requestMethod = method
        connection.connectTimeout = timeoutMs
        connection.readTimeout = timeoutMs
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 GameLens")
        headers.forEach { (k, v) -> connection.setRequestProperty(k, v) }
        if (body != null) {
            connection.doOutput = true
            connection.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        code to text
    } finally {
        connection.disconnect()
    }
}

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

// ---------- MyMemory (ฟรี มีโควตารายวัน) ----------

object MyMemoryTranslate {
    suspend fun translate(text: String, source: GameLanguage, target: GameLanguage, email: String): String {
        val parts = splitIntoChunks(text, 450).map { translateChunk(it, source, target, email) }
        return parts.joinToString(if (target.joinsWithoutSpaces) "" else " ")
    }

    private suspend fun translateChunk(text: String, source: GameLanguage, target: GameLanguage, email: String): String {
        var url = "https://api.mymemory.translated.net/get?q=${enc(text)}" +
            "&langpair=${enc("${source.webCode}|${target.webCode}")}"
        if (email.contains("@")) url += "&de=${enc(email.trim())}"
        val (_, body) = httpRequest(url)
        val json = try { JSONObject(body) } catch (e: Exception) {
            throw TranslationException("อ่านผลจาก MyMemory ไม่ได้")
        }
        val status = json.opt("responseStatus")?.toString()?.toIntOrNull() ?: 0
        val translated = json.optJSONObject("responseData")?.optString("translatedText").orEmpty()
        if (status == 429 || translated.uppercase().contains("MYMEMORY WARNING")) {
            throw TranslationException("ใช้โควตาฟรีของ MyMemory วันนี้หมดแล้ว — ใส่อีเมลเพื่อเพิ่มโควตา หรือเปลี่ยนตัวแปล")
        }
        if (status != 200 || translated.isEmpty()) {
            throw TranslationException("MyMemory: ${json.optString("responseDetails", "HTTP $status")}")
        }
        return translated
            .replace("&#39;", "'").replace("&quot;", "\"")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
    }
}

// ---------- Claude AI (เสียเงิน) ----------

object ClaudeTranslate {
    suspend fun translate(
        text: String, source: GameLanguage, target: GameLanguage,
        apiKey: String, model: String, context: List<HistoryEntry>,
    ): String {
        if (apiKey.isBlank()) throw TranslationException("ยังไม่ได้ใส่ Claude API Key ในหน้าตั้งค่า")
        val system = """
            You are a professional video game localizer. Translate in-game text from ${source.englishName} into natural, fluent ${target.englishName}, like high-quality game subtitles.
            Rules:
            - Output ONLY the translation. No quotes, notes, or explanations.
            - The text comes from OCR and may contain small recognition errors; silently fix obvious ones.
            - Keep character names, places, and terms consistent with the previous lines.
            - Match the speaker's tone and personality. Keep it concise.
        """.trimIndent()
        val user = buildString {
            val recent = context.takeLast(6)
            if (recent.isNotEmpty()) {
                append("Previous lines (context only, do not translate again):\n")
                append(recent.joinToString("\n") { "${it.original}\n→ ${it.translated}" })
                append("\n\n")
            }
            append("Translate this line:\n$text")
        }
        val payload = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        val (code, body) = httpRequest(
            "https://api.anthropic.com/v1/messages",
            method = "POST",
            headers = mapOf(
                "content-type" to "application/json",
                "x-api-key" to apiKey.trim(),
                "anthropic-version" to "2023-06-01",
            ),
            body = payload.toString(),
            timeoutMs = 20000,
        )
        if (code != 200) {
            val message = try { JSONObject(body).getJSONObject("error").getString("message") } catch (e: Exception) { "HTTP $code" }
            throw TranslationException("แปลไม่สำเร็จ: $message")
        }
        val content = JSONObject(body).optJSONArray("content") ?: JSONArray()
        val result = buildString {
            for (i in 0 until content.length()) append(content.optJSONObject(i)?.optString("text").orEmpty())
        }.trim()
        if (result.isEmpty()) throw TranslationException("ไม่มีข้อความตอบกลับ")
        return result
    }
}
