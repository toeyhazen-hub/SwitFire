package com.gamelens.app

import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

val Accent = Color(0xFF6B5CF5)
private val PanelColor = Color(0xFF1C1C22)
private val ButtonColor = Color(0xFF2C2C36)

@Composable
fun GameLensTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Accent, secondary = Accent),
        content = content,
    )
}

enum class DialogKind { SETTINGS, CUSTOMIZE, HISTORY, ABOUT }

/** พื้นที่ภาพเกมจริงภายในกรอบ (ไม่รวมขอบดำ) หน่วยเป็นพิกเซล */
data class ContentRect(val left: Float, val top: Float, val width: Float, val height: Float) {
    val right get() = left + width
    val bottom get() = top + height
}

private fun fitRect(contentW: Int, contentH: Int, boxW: Float, boxH: Float): ContentRect {
    if (contentW <= 0 || contentH <= 0 || boxW <= 0f || boxH <= 0f) return ContentRect(0f, 0f, boxW, boxH)
    val scale = min(boxW / contentW, boxH / contentH)
    val w = contentW * scale
    val h = contentH * scale
    return ContentRect((boxW - w) / 2, (boxH - h) / 2, w, h)
}

private fun viewRect(roi: NormRect, c: ContentRect) =
    ContentRect(c.left + roi.x * c.width, c.top + roi.y * c.height, roi.w * c.width, roi.h * c.height)

// ================= หน้าหลัก =================

@Composable
fun MainScreen(vm: AppViewModel) {
    val s = vm.settings
    var immersive by remember { mutableStateOf(false) }
    var showHint by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<DialogKind?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.loadTestImage(uri)
    }
    val pickImage = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    LaunchedEffect(showHint) {
        if (showHint) {
            delay(2500)
            showHint = false
        }
    }

    Column(Modifier.fillMaxSize().background(if (immersive) Color.Black else PanelColor)) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(if (immersive) 0.dp else 10.dp)
                .clip(RoundedCornerShape(if (immersive) 0.dp else 14.dp))
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = {
                        if (!vm.isSelectingRegion) {
                            immersive = !immersive
                            showHint = immersive
                        }
                    })
                }
        ) {
            // ภาพเกมต้องอยู่เสมอ (OCR ดึงภาพจากตรงนี้) โหมดจอซับไตเติลจึงวาดทับด้านบน
            VideoArea(vm, interactive = true, scale = 1f)
            if (!vm.isLive && vm.testImage == null) Placeholder(vm, pickImage)
            if (s.subtitleScreenMode && !vm.isSelectingRegion) SubtitleScreen(vm)
            if (s.showDiagnostics) {
                Text(
                    "${vm.measuredFps} fps · ${vm.contentWidth}×${vm.contentHeight} · เริ่มภาพใหม่ ${vm.autoRestartCount} ครั้ง",
                    color = Color(0xFF34C759),
                    fontSize = 13.sp,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
            if (showHint) {
                Text(
                    "แตะสองครั้งเพื่อแสดงแถบเครื่องมือ",
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .background(Color(0xCC222222), RoundedCornerShape(50))
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                )
            }
        }
        if (!immersive) {
            Toolbar(
                vm,
                onDialog = { dialog = it },
                onImmersive = { immersive = true; showHint = true },
            )
        }
    }

    when (dialog) {
        DialogKind.SETTINGS -> SettingsDialog(vm, pickImage, onAbout = { dialog = DialogKind.ABOUT }) { dialog = null }
        DialogKind.ABOUT -> AboutDialog { dialog = DialogKind.SETTINGS }
        DialogKind.CUSTOMIZE -> CustomizeDialog(vm) { dialog = null }
        DialogKind.HISTORY -> HistoryDialog(vm) { dialog = null }
        null -> Unit
    }
}

/** หน้าจอบนทีวี */
@Composable
fun TvScreen(vm: AppViewModel) {
    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val density = LocalDensity.current
        // ทีวีจอใหญ่ ขยายตัวอักษรตามความกว้าง
        val scale = max(1f, with(density) { maxWidth.toPx() } / with(density) { 1280.dp.toPx() } * 1.4f)
        VideoArea(vm, interactive = false, scale = scale)
    }
}

// ================= ภาพเกม + กรอบ + คำแปล =================

@Composable
fun VideoArea(vm: AppViewModel, interactive: Boolean, scale: Float) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val boxW = constraints.maxWidth.toFloat()
        val boxH = constraints.maxHeight.toFloat()
        val content = fitRect(vm.contentWidth, vm.contentHeight, boxW, boxH)
        val contentModifier = Modifier
            .offset { IntOffset(content.left.roundToInt(), content.top.roundToInt()) }
            .size(with(density) { content.width.toDp() }, with(density) { content.height.toDp() })

        val bitmap = vm.testImage
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = contentModifier,
            )
        } else {
            AndroidView(
                factory = { ctx ->
                    SurfaceView(ctx).apply {
                        if (interactive) vm.ocrSurface = java.lang.ref.WeakReference(this)
                        holder.addCallback(object : SurfaceHolder.Callback {
                            override fun surfaceCreated(holder: SurfaceHolder) {
                                vm.capture.addSurface(holder.surface)
                            }

                            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

                            override fun surfaceDestroyed(holder: SurfaceHolder) {
                                vm.capture.removeSurface(holder.surface)
                            }
                        })
                    }
                },
                modifier = contentModifier,
            )
        }

        RegionOverlay(vm, content, boxW, boxH, interactive, scale)
    }
}

@Composable
private fun RegionOverlay(
    vm: AppViewModel,
    content: ContentRect,
    boxW: Float,
    boxH: Float,
    interactive: Boolean,
    scale: Float,
) {
    val s = vm.settings
    var dragStart by remember { mutableStateOf<Offset?>(null) }
    var dragEnd by remember { mutableStateOf<Offset?>(null) }

    fun selection(): Rect? {
        val a = dragStart ?: return null
        val b = dragEnd ?: return null
        val left = max(min(a.x, b.x), content.left)
        val top = max(min(a.y, b.y), content.top)
        val right = min(max(a.x, b.x), content.right)
        val bottom = min(max(a.y, b.y), content.bottom)
        return if (right > left && bottom > top) Rect(left, top, right, bottom) else null
    }

    if (interactive && vm.isSelectingRegion) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(content) {
                    detectDragGestures(
                        onDragStart = { dragStart = it; dragEnd = it },
                        onDragEnd = {
                            val r = selection()
                            if (r != null && r.width > 20 && r.height > 12 && content.width > 0 && content.height > 0) {
                                vm.setRegion(
                                    NormRect(
                                        (r.left - content.left) / content.width,
                                        (r.top - content.top) / content.height,
                                        r.width / content.width,
                                        r.height / content.height,
                                    )
                                )
                            }
                            dragStart = null
                            dragEnd = null
                        },
                        onDragCancel = { dragStart = null; dragEnd = null },
                    ) { change, _ -> dragEnd = change.position }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val sel = selection()
                val path = Path().apply {
                    fillType = PathFillType.EvenOdd
                    addRect(Rect(0f, 0f, size.width, size.height))
                    if (sel != null) addRect(sel)
                }
                drawPath(path, Color.Black.copy(alpha = 0.5f))
                if (sel != null) {
                    drawRect(Accent, sel.topLeft, sel.size, style = Stroke(width = 3.dp.toPx()))
                }
            }
            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp)
                    .background(Color(0xDD222230), RoundedCornerShape(50))
                    .padding(start = 18.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("ลากนิ้วคลุมบริเวณที่มีข้อความในเกม", color = Color.White)
                TextButton(onClick = { vm.setSelecting(false) }) { Text("ยกเลิก") }
            }
        }
        return
    }

    val roi = s.roi ?: return
    val r = viewRect(roi, content)
    if (interactive && s.showRegionOutline) {
        val color = s.textColor.copy(alpha = 0.55f)
        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                color,
                Offset(r.left, r.top),
                Size(r.width, r.height),
                style = Stroke(width = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))),
            )
        }
    }
    SubtitleOverlay(vm, r, boxH, scale)
}

@Composable
private fun SubtitleOverlay(vm: AppViewModel, r: ContentRect, boxH: Float, scale: Float) {
    if (vm.translatedText.isEmpty() && !vm.isTranslating) return
    val s = vm.settings
    val density = LocalDensity.current
    val fontPx = with(density) { (s.fontSize * scale).sp.toPx() }
    var needed = fontPx * 1.6f + with(density) { 14.dp.toPx() }
    if (s.showOriginal) needed += fontPx * 1.4f + with(density) { 16.dp.toPx() }
    if (s.showPronunciation && vm.pronunciation != null) needed += fontPx + with(density) { 14.dp.toPx() }

    val position = when {
        s.overlayPosition != OverlayPosition.AUTO -> s.overlayPosition
        r.top >= needed -> OverlayPosition.ABOVE
        boxH - r.bottom >= needed -> OverlayPosition.BELOW
        else -> OverlayPosition.COVER
    }
    val gap = with(density) { 6.dp.toPx() }
    val top: Float
    val height: Float
    val align: Alignment
    when (position) {
        OverlayPosition.ABOVE -> { top = 0f; height = max(r.top - gap, 1f); align = Alignment.BottomCenter }
        OverlayPosition.BELOW -> { top = r.bottom + gap; height = max(boxH - r.bottom - gap, 1f); align = Alignment.TopCenter }
        else -> { top = r.top; height = r.height; align = Alignment.Center }
    }
    Box(
        Modifier
            .offset { IntOffset(r.left.roundToInt(), top.roundToInt()) }
            .size(with(density) { r.width.toDp() }, with(density) { height.toDp() }),
        contentAlignment = align,
    ) {
        SubtitleBars(vm, scale, Modifier.wrapContentHeight(unbounded = true))
    }
}

@Composable
fun SubtitleBars(vm: AppViewModel, scale: Float, modifier: Modifier = Modifier) {
    val s = vm.settings
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy((4 * scale).dp)) {
        if (s.showOriginal && vm.originalText.isNotEmpty()) {
            SubtitleBar(vm.originalText, s.fontSize * 0.8f, s, scale)
        }
        val reading = vm.pronunciation
        if (s.showPronunciation && !reading.isNullOrEmpty()) {
            SubtitleBar(reading, s.fontSize * 0.65f, s, scale, italic = true)
        }
        SubtitleBar(if (vm.isTranslating) "กำลังแปล…" else vm.translatedText, s.fontSize, s, scale)
    }
}

@Composable
fun SubtitleBar(text: String, size: Float, s: AppSettings, scale: Float = 1f, italic: Boolean = false) {
    Text(
        text,
        color = s.textColor,
        fontSize = (size * scale).sp,
        lineHeight = (size * scale * 1.35f).sp,
        fontWeight = FontWeight.SemiBold,
        fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = s.opacity), RoundedCornerShape(8.dp))
            .padding(horizontal = (12 * scale).dp, vertical = (6 * scale).dp),
    )
}

// ================= โหมดจอซับไตเติล =================

@Composable
fun SubtitleScreen(vm: AppViewModel) {
    val s = vm.settings
    val recent = vm.history.takeLast(max(s.subtitleLines, 1))
    Column(
        Modifier.fillMaxSize().background(Color.Black).padding(40.dp),
        verticalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (recent.isEmpty()) {
            Text("รอข้อความจากเกม…", color = Color.White.copy(alpha = 0.4f), fontSize = 22.sp)
        }
        recent.forEachIndexed { index, entry ->
            val latest = index == recent.lastIndex
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (s.showOriginal) {
                    Text(
                        entry.original,
                        color = Color.White.copy(alpha = if (latest) 0.6f else 0.35f),
                        fontSize = (s.fontSize * if (latest) 0.9f else 0.7f).sp,
                        textAlign = TextAlign.Center,
                    )
                }
                Text(
                    entry.translated,
                    color = s.textColor.copy(alpha = if (latest) 1f else 0.45f),
                    fontSize = (s.fontSize * if (latest) 1.8f else 1.2f).sp,
                    lineHeight = (s.fontSize * if (latest) 2.4f else 1.6f).sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )
            }
        }
        if (vm.isTranslating) CircularProgressIndicator(color = Color.White)
    }
}

// ================= ตอนยังไม่มีภาพ =================

@Composable
private fun Placeholder(vm: AppViewModel, pickImage: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(30.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.SportsEsports, null, tint = Accent, modifier = Modifier.size(54.dp))
        Text(vm.status, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Text(
            "Nintendo Switch → Dock → HDMI → Capture Card → USB-C ของแท็บเล็ต",
            color = Color.White.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { vm.retryCapture() }) {
                Icon(Icons.Filled.Refresh, null)
                Spacer(Modifier.width(6.dp))
                Text("เริ่มภาพใหม่")
            }
            OutlinedButton(onClick = pickImage) { Text("ทดสอบด้วยภาพหน้าจอ") }
        }
    }
}

// ================= แถบเครื่องมือ =================

@Composable
private fun Toolbar(vm: AppViewModel, onDialog: (DialogKind) -> Unit, onImmersive: () -> Unit) {
    val s = vm.settings
    Row(
        Modifier.fillMaxWidth().height(68.dp).padding(start = 14.dp, end = 14.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        LanguageMenu(s)
        Row(
            Modifier.weight(1f).clickable { vm.retryCapture() },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val dot = when {
                vm.isLive -> Color(0xFF34C759)
                vm.testImage != null -> Color(0xFFFF9F0A)
                else -> Color(0xFFFF453A)
            }
            Box(Modifier.size(8.dp).background(dot, CircleShape))
            Spacer(Modifier.width(6.dp))
            if (vm.externalDisplayConnected) {
                Icon(Icons.Filled.Tv, null, tint = Color(0xFF34C759), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
            }
            Text(
                if (vm.isPaused) "หยุดชั่วคราว" else vm.status,
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
            if (vm.testImage == null) {
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Filled.Refresh, null, tint = Color.White.copy(alpha = 0.5f), modifier = Modifier.size(14.dp))
            }
        }
        ToolButton(if (vm.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause, vm.isPaused) { vm.togglePause() }
        ToolButton(Icons.Filled.Translate) { vm.translateNow() }
        ToolButton(Icons.Filled.Crop, vm.isSelectingRegion) { vm.setSelecting(!vm.isSelectingRegion) }
        ToolButton(Icons.Filled.ChatBubble, s.subtitleScreenMode) { s.subtitleScreenMode = !s.subtitleScreenMode }
        ToolButton(Icons.Filled.History) { onDialog(DialogKind.HISTORY) }
        ToolButton(Icons.Filled.Palette) { onDialog(DialogKind.CUSTOMIZE) }
        ToolButton(Icons.Filled.Settings) { onDialog(DialogKind.SETTINGS) }
        ToolButton(Icons.Filled.Fullscreen) { onImmersive() }
    }
}

@Composable
private fun ToolButton(icon: ImageVector, active: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .size(width = 52.dp, height = 48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (active) Accent else ButtonColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = if (active) Color.White else Color(0xFFB9B2FF))
    }
}

@Composable
private fun LanguageMenu(s: AppSettings) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier
                .height(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(ButtonColor)
                .clickable { expanded = true }
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("${s.sourceLanguage.flag} → ${s.targetLanguage.flag} ${s.targetLanguage.name}", color = Color.White, fontWeight = FontWeight.SemiBold)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            Text("ภาษาในเกม", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            Languages.sources.forEach { lang ->
                DropdownMenuItem(
                    text = { Text("${lang.flag} ${lang.name}" + if (lang.id == s.sourceLangId) "  ✓" else "") },
                    onClick = { s.sourceLangId = lang.id; expanded = false },
                )
            }
            HorizontalDivider()
            Text("แปลเป็น", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            Languages.targets.forEach { lang ->
                DropdownMenuItem(
                    text = { Text("${lang.flag} ${lang.name}" + if (lang.id == s.targetLangId) "  ✓" else "") },
                    onClick = { s.targetLangId = lang.id; expanded = false },
                )
            }
        }
    }
}

@Suppress("unused")
private fun Float.near(other: Float) = abs(this - other) < 0.5f
