package com.gamelens.app

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder

/**
 * ดึงเสียงเกมจาก Capture Card (USB Audio) แล้วเล่นออกลำโพง/หูฟังของแท็บเล็ต
 * จะไม่ใช้ไมค์ในตัวเด็ดขาด เพื่อกันเสียงหอน
 */
class AudioPassthrough(private val context: Context) {
    @Volatile private var running = false
    private var thread: Thread? = null
    @Volatile private var track: AudioTrack? = null
    private var record: AudioRecord? = null

    var volume: Float = 1f
        set(value) {
            field = value
            track?.setVolume(value)
        }

    val isRunning get() = running

    private fun isUsb(type: Int?) =
        type == AudioDeviceInfo.TYPE_USB_DEVICE || type == AudioDeviceInfo.TYPE_USB_HEADSET

    /** คืนค่าข้อความ error หรือ null ถ้าสำเร็จ */
    fun start(): String? = try {
        startInternal()
    } catch (e: Exception) {
        stop()
        "เปิดเสียงเกมไม่ได้: ${e.message}"
    }

    @SuppressLint("MissingPermission")
    private fun startInternal(): String? {
        if (running) return null
        val manager = context.getSystemService(AudioManager::class.java)
        val usb = manager.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { isUsb(it.type) }
            ?: return "ไม่พบเสียงจาก Capture Card (USB Audio)"

        val rate = usb.sampleRates.let { if (it.isEmpty() || 48000 in it) 48000 else it.max() }
        val stereo = usb.channelCounts.let { it.isEmpty() || it.any { c -> c >= 2 } }
        val inMask = if (stereo) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO
        val outMask = if (stereo) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT

        val minIn = AudioRecord.getMinBufferSize(rate, inMask, encoding)
        val minOut = AudioTrack.getMinBufferSize(rate, outMask, encoding)
        if (minIn <= 0 || minOut <= 0) return "ระบบเสียงไม่รองรับรูปแบบเสียงของการ์ด"

        val source = if (manager.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true")
            MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.VOICE_RECOGNITION

        val newRecord = try {
            AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(rate).setEncoding(encoding).setChannelMask(inMask).build()
                )
                .setBufferSizeInBytes(minIn * 2)
                .build()
        } catch (e: Exception) {
            return "เปิดเสียงจากการ์ดไม่ได้: ${e.message}"
        }
        newRecord.setPreferredDevice(usb)
        newRecord.startRecording()

        // ตรวจว่ารับเสียงจาก USB จริง ๆ (ไม่ใช่ไมค์ในตัว)
        var routedOk = false
        repeat(10) {
            if (isUsb(newRecord.routedDevice?.type)) { routedOk = true; return@repeat }
            Thread.sleep(50)
        }
        if (!routedOk) {
            newRecord.stop(); newRecord.release()
            return "ระบบไม่ยอมรับเสียงจาก USB (กันเสียงหอนจากไมค์ในตัว)"
        }

        val newTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setSampleRate(rate).setEncoding(encoding).setChannelMask(outMask).build()
            )
            .setBufferSizeInBytes(minOut * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        newTrack.setVolume(volume)
        newTrack.play()

        record = newRecord
        track = newTrack
        running = true
        thread = Thread({
            val buffer = ByteArray(minIn)
            while (running) {
                val n = newRecord.read(buffer, 0, buffer.size)
                if (n > 0) newTrack.write(buffer, 0, n) else if (n < 0) break
            }
        }, "GameLens-Audio").also { it.start() }
        return null
    }

    fun stop() {
        running = false
        thread?.join(500)
        thread = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        record = null
        try { track?.stop() } catch (_: Exception) {}
        track?.release()
        track = null
    }
}
