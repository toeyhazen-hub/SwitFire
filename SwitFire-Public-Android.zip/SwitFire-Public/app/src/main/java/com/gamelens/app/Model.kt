package com.gamelens.app

import android.icu.text.BreakIterator
import android.icu.text.Transliterator
import com.google.mlkit.nl.translate.TranslateLanguage
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/** ชุดตัวอักษรที่ใช้เลือกตัว OCR ของ ML Kit */
enum class OcrScript { LATIN, JAPANESE, CHINESE, KOREAN }

data class GameLanguage(
    val id: String,
    val name: String,
    val flag: String,
    /** null = ใช้เป็นภาษาต้นทาง (OCR) ไม่ได้ */
    val ocr: OcrScript?,
) {
    val englishName: String
        get() = Locale.forLanguageTag(id).getDisplayName(Locale.ENGLISH)

    /** ภาษาที่ไม่เว้นวรรคระหว่างคำ */
    val joinsWithoutSpaces: Boolean
        get() = id in setOf("ja", "zh-Hans", "zh-Hant", "th")

    /** รหัสภาษาที่ Google / MyMemory ใช้ */
    val webCode: String
        get() = when (id) {
            "zh-Hans" -> "zh-CN"
            "zh-Hant" -> "zh-TW"
            else -> id
        }

    /** รหัสภาษาของ ML Kit Translate (null = ไม่รองรับ) */
    val mlKitCode: String?
        get() = TranslateLanguage.fromLanguageTag(if (id.startsWith("zh")) "zh" else id)
}

object Languages {
    val all = listOf(
        GameLanguage("en", "อังกฤษ", "🇬🇧", OcrScript.LATIN),
        GameLanguage("ja", "ญี่ปุ่น", "🇯🇵", OcrScript.JAPANESE),
        GameLanguage("zh-Hans", "จีนตัวย่อ", "🇨🇳", OcrScript.CHINESE),
        GameLanguage("zh-Hant", "จีนตัวเต็ม", "🇹🇼", OcrScript.CHINESE),
        GameLanguage("ko", "เกาหลี", "🇰🇷", OcrScript.KOREAN),
        GameLanguage("fr", "ฝรั่งเศส", "🇫🇷", OcrScript.LATIN),
        GameLanguage("de", "เยอรมัน", "🇩🇪", OcrScript.LATIN),
        GameLanguage("es", "สเปน", "🇪🇸", OcrScript.LATIN),
        GameLanguage("th", "ไทย", "🇹🇭", null),
        GameLanguage("vi", "เวียดนาม", "🇻🇳", null),
    )
    val sources = all.filter { it.ocr != null }
    val targets = all
    fun find(id: String) = all.firstOrNull { it.id == id } ?: all[0]
}

enum class TranslationEngine(val title: String, val detail: String) {
    MLKIT(
        "Google ML Kit (ฟรี ออฟไลน์)",
        "ฟรีและทำงานออฟไลน์ ไม่จำกัดจำนวน ครั้งแรกต้องดาวน์โหลดภาษา (ภาษาละประมาณ 30 MB)"
    ),
    MYMEMORY(
        "MyMemory (ฟรี ออนไลน์)",
        "ฟรีอย่างเป็นทางการ ต้องต่อเน็ต มีโควตารายวัน (ใส่อีเมลเพื่อเพิ่มโควตา)"
    ),
    CLAUDE(
        "Claude AI (เสียเงิน)",
        "แปลเป็นธรรมชาติและเข้าใจบริบทที่สุด แต่ต้องใช้ API Key และเสียค่าใช้จ่าย"
    ),
}

enum class OverlayPosition(val title: String) {
    AUTO("อัตโนมัติ"), ABOVE("เหนือกรอบ"), BELOW("ใต้กรอบ"), COVER("ทับกรอบ")
}

/** กรอบแบบ normalized (0–1) จุดเริ่มมุมซ้ายบน */
data class NormRect(val x: Float, val y: Float, val w: Float, val h: Float) {
    fun encode() = "$x,$y,$w,$h"

    companion object {
        fun decode(s: String?): NormRect? {
            val p = s?.split(",")?.mapNotNull { it.toFloatOrNull() } ?: return null
            return if (p.size == 4) NormRect(p[0], p[1], p[2], p[3]) else null
        }
    }
}

/** กรอบ OCR หนึ่งกรอบ พร้อมการตั้งค่าหน้าตาของตัวเอง */
data class Region(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "กรอบใหม่",
    val rect: NormRect,
    val fontSize: Float = 24f,
    val colorIndex: Int = 0,
    val showOriginal: Boolean = true,
    val overlayPosition: OverlayPosition = OverlayPosition.AUTO,
    val enabled: Boolean = true,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name)
        .put("x", rect.x.toDouble()).put("y", rect.y.toDouble())
        .put("w", rect.w.toDouble()).put("h", rect.h.toDouble())
        .put("fontSize", fontSize.toDouble()).put("colorIndex", colorIndex)
        .put("showOriginal", showOriginal).put("position", overlayPosition.name)
        .put("enabled", enabled)

    companion object {
        fun fromJson(o: JSONObject): Region? = try {
            Region(
                id = o.optString("id", UUID.randomUUID().toString()),
                name = o.optString("name", "กรอบ"),
                rect = NormRect(
                    o.getDouble("x").toFloat(), o.getDouble("y").toFloat(),
                    o.getDouble("w").toFloat(), o.getDouble("h").toFloat(),
                ),
                fontSize = o.optDouble("fontSize", 24.0).toFloat(),
                colorIndex = o.optInt("colorIndex", 0),
                showOriginal = o.optBoolean("showOriginal", true),
                overlayPosition = OverlayPosition.entries
                    .firstOrNull { it.name == o.optString("position") } ?: OverlayPosition.AUTO,
                enabled = o.optBoolean("enabled", true),
            )
        } catch (e: Exception) {
            null
        }

        fun listFromJson(text: String): List<Region> = try {
            if (text.isBlank()) emptyList() else {
                val array = JSONArray(text)
                (0 until array.length()).mapNotNull { index ->
                    val item = array.optJSONObject(index)
                    if (item == null) null else fromJson(item)
                }
            }
        } catch (e: Exception) {
            emptyList()
        }

        fun listToJson(regions: List<Region>): String {
            val array = JSONArray()
            regions.forEach { array.put(it.toJson()) }
            return array.toString()
        }
    }
}

data class HistoryEntry(
    val original: String,
    val translated: String,
    val regionName: String = "",
    val id: String = UUID.randomUUID().toString(),
)

object Similarity {
    fun ratio(a: String, b: String): Double {
        if (a == b) return 1.0
        val x = a.take(400)
        val y = b.take(400)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        var prev = IntArray(y.length + 1) { it }
        var cur = IntArray(y.length + 1)
        for (i in 1..x.length) {
            cur[0] = i
            for (j in 1..y.length) {
                cur[j] = if (x[i - 1] == y[j - 1]) prev[j - 1]
                else minOf(prev[j - 1], prev[j], cur[j - 1]) + 1
            }
            val t = prev; prev = cur; cur = t
        }
        return 1.0 - prev[y.length].toDouble() / maxOf(x.length, y.length)
    }

    fun isSame(a: String, b: String, maxLengthDiff: Int): Boolean {
        if (a == b) return true
        if (a.isEmpty() || b.isEmpty() || kotlin.math.abs(a.length - b.length) > maxLengthDiff) return false
        return ratio(a, b) >= 0.9
    }
}

/**
 * ตัดสินว่าข้อความ "นิ่ง" แล้วหรือยัง
 * เกมส่วนใหญ่ขึ้นข้อความทีละตัวอักษร ถ้าแปลทันทีจะได้ประโยคครึ่ง ๆ กลาง ๆ
 */
class TextStabilizer {
    sealed class Event {
        object None : Event()
        object Cleared : Event()
        data class NewText(val text: String) : Event()
    }

    var requiredStableCount = 2
    private var candidate = ""
    private var stableCount = 0
    private var emptyCount = 0
    private var lastEmitted = ""

    fun feed(text: String): Event {
        if (text.length < 2) {
            candidate = ""
            stableCount = 0
            emptyCount++
            if (emptyCount == 3 && lastEmitted.isNotEmpty()) {
                lastEmitted = ""
                return Event.Cleared
            }
            return Event.None
        }
        emptyCount = 0
        stableCount = if (Similarity.isSame(text, candidate, 1)) stableCount + 1 else 1
        candidate = text
        if (stableCount < requiredStableCount) return Event.None
        if (Similarity.isSame(candidate, lastEmitted, 3)) return Event.None
        lastEmitted = candidate
        return Event.NewText(candidate)
    }

    fun markEmitted(text: String) {
        lastEmitted = text
        candidate = text
        stableCount = requiredStableCount
    }

    fun reset() {
        candidate = ""
        stableCount = 0
        emptyCount = 0
        lastEmitted = ""
    }
}

/** คำอ่านแบบตัวอักษรโรมัน (คานะ → โรมาจิ, จีน → พินอิน) */
object Pronunciation {
    private val japanese by lazy { Transliterator.getInstance("Hiragana-Latin; Katakana-Latin") }
    private val chinese by lazy { Transliterator.getInstance("Han-Latin") }

    fun romanize(text: String, language: GameLanguage): String? = try {
        when {
            text.isEmpty() -> null
            language.id == "ja" -> japanese.transliterate(text)
            language.id.startsWith("zh") -> chinese.transliterate(text)
            else -> null
        }
    } catch (e: Exception) {
        null
    }
}

/** แบ่งข้อความยาวเป็นท่อนตามประโยค (สำหรับบริการที่จำกัดความยาว) */
fun splitIntoChunks(text: String, maxBytes: Int): List<String> {
    if (text.toByteArray().size <= maxBytes) return listOf(text)
    val iterator = BreakIterator.getSentenceInstance()
    iterator.setText(text)
    val sentences = mutableListOf<String>()
    var start = iterator.first()
    var end = iterator.next()
    while (end != BreakIterator.DONE) {
        sentences += text.substring(start, end)
        start = end
        end = iterator.next()
    }
    val result = mutableListOf<String>()
    var current = StringBuilder()
    for (sentence in sentences) {
        for (ch in sentence) {
            if (current.toString().toByteArray().size + ch.toString().toByteArray().size > maxBytes) {
                result += current.toString()
                current = StringBuilder()
            }
            current.append(ch)
        }
        if (current.toString().toByteArray().size > maxBytes * 3 / 4) {
            result += current.toString()
            current = StringBuilder()
        }
    }
    if (current.isNotEmpty()) result += current.toString()
    return result.map { it.trim() }.filter { it.isNotEmpty() }
}
