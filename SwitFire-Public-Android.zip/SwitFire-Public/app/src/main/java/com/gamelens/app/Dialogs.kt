package com.gamelens.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.roundToInt

private val DialogColor = Color(0xFF1E1E26)
private val RowColor = Color(0xFF2A2A34)

// ================= ส่วนประกอบพื้นฐาน =================

@Composable
private fun AppDialog(
    title: String,
    onDismiss: () -> Unit,
    extraAction: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = DialogColor,
            modifier = Modifier.fillMaxWidth(0.72f).fillMaxHeight(0.92f),
        ) {
            Column {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.width(110.dp)) { extraAction?.invoke() }
                    Text(
                        title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                    Box(Modifier.width(110.dp), contentAlignment = Alignment.CenterEnd) {
                        TextButton(onClick = onDismiss) { Text("เสร็จ") }
                    }
                }
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    content = content,
                )
            }
        }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(text, color = Color(0xFFB9B2FF), fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 10.dp))
}

@Composable
private fun Note(text: String, color: Color = Color.White.copy(alpha = 0.55f)) {
    Text(text, color = color, fontSize = 13.sp)
}

@Composable
private fun SettingRow(content: @Composable () -> Unit) {
    Box(
        Modifier.fillMaxWidth().background(RowColor, RoundedCornerShape(12.dp)).padding(horizontal = 16.dp, vertical = 10.dp)
    ) { content() }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    SettingRow {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int = 0, onChange: (Float) -> Unit) {
    SettingRow {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, modifier = Modifier.width(220.dp))
            Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun StepperRow(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    SettingRow {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { onChange((value - 1).coerceIn(range)) }) { Text("−") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { onChange((value + 1).coerceIn(range)) }) { Text("+") }
        }
    }
}

@Composable
private fun <T> ChoiceRow(label: String, options: List<T>, selected: T, titleOf: (T) -> String, onSelect: (T) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    SettingRow {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, modifier = Modifier.weight(1f))
            Box {
                TextButton(onClick = { expanded = true }) { Text(titleOf(selected) + "  ▾") }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    options.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(titleOf(option) + if (option == selected) "  ✓" else "") },
                            onClick = { onSelect(option); expanded = false },
                        )
                    }
                }
            }
        }
    }
}

// ================= ตั้งค่า =================

@Composable
fun SettingsDialog(vm: AppViewModel, pickImage: () -> Unit, onAbout: () -> Unit, onDismiss: () -> Unit) {
    val s = vm.settings
    LaunchedEffect(Unit) { vm.refreshMlKitStatus() }

    AppDialog("ตั้งค่า", onDismiss) {
        SectionHeader("แหล่งภาพ")
        Note("สถานะ: ${vm.status}" + if (vm.autoRestartCount > 0) " · เริ่มภาพใหม่อัตโนมัติ ${vm.autoRestartCount} ครั้ง" else "")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.retryCapture() }) { Text("เริ่มภาพใหม่ (ถ้าภาพค้าง/จอดำ)") }
            OutlinedButton(onClick = { onDismiss(); pickImage() }) { Text("ทดสอบด้วยภาพหน้าจอ") }
        }
        if (vm.testImage != null) {
            OutlinedButton(onClick = { vm.exitTestImage() }) { Text("กลับไปใช้ภาพจาก Capture Card") }
        }
        ChoiceRow("ความละเอียดสูงสุด", listOf(1080, 1440, 2160), s.maxResolution, {
            when (it) { 2160 -> "4K (2160p)"; 1440 -> "1440p"; else -> "1080p (แนะนำ)" }
        }) { s.maxResolution = it }
        Note("แอปเลือก 60fps ก่อนเสมอ แล้วค่อยเลือกความละเอียดสูงสุดที่การ์ดส่งได้ที่ 60fps ถ้าการ์ดส่ง 4K ได้แค่ 30fps แอปจะเลือก 1080p60 แทน")
        ChoiceRow("โหมดภาพของการ์ด", listOf("") + vm.availableModes, s.preferredMode, {
            if (it.isEmpty()) "อัตโนมัติ" else it
        }) { s.preferredMode = it }
        Note("เลือกโหมดที่เป็น 16:9 เช่น 1920x1080@60 เพื่อให้ได้ภาพเต็มคุณภาพ")
        ChoiceRow("สัดส่วนภาพ", listOf(0, 1, 2, 3), s.aspectMode, {
            when (it) { 1 -> "16:9"; 2 -> "4:3"; 3 -> "เต็มพื้นที่"; else -> "อัตโนมัติ" }
        }) { s.aspectMode = it }
        Note("ถ้าภาพยืดหรือมีขอบดำผิดปกติ ให้ลองตั้งเป็น 16:9")
        SwitchRow("แสดง FPS และข้อมูลตรวจสอบบนจอ", s.showDiagnostics) { s.showDiagnostics = it }

        SectionHeader("เสียงเกม")
        SwitchRow("เล่นเสียงเกมผ่านแท็บเล็ต", s.audioEnabled) { s.audioEnabled = it }
        SliderRow("ระดับเสียง", s.audioVolume, 0f..1f) { s.audioVolume = it }
        if (vm.audioStatus.isNotEmpty()) Note(vm.audioStatus)

        SectionHeader("ภาษา")
        ChoiceRow("ภาษาในเกม", Languages.sources, s.sourceLanguage, { "${it.flag} ${it.name}" }) { s.sourceLangId = it.id }
        ChoiceRow("แปลเป็น", Languages.targets, s.targetLanguage, { "${it.flag} ${it.name}" }) { s.targetLangId = it.id }

        SectionHeader("เครื่องมือแปล")
        ChoiceRow("ใช้ตัวแปล", TranslationEngine.entries, s.engine, { it.title }) { s.engine = it }
        Note(s.engine.detail)
        when (s.engine) {
            TranslationEngine.MLKIT -> {
                SettingRow {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        when {
                            vm.mlKitDownloading -> {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text("กำลังดาวน์โหลดภาษา…", color = Color.White)
                            }
                            vm.mlKitReady == true ->
                                Text("✅ ดาวน์โหลดภาษาแล้ว พร้อมใช้งานออฟไลน์", color = Color(0xFF34C759))
                            vm.mlKitReady == false -> {
                                Text("⚠️ ยังไม่ได้ดาวน์โหลดภาษา", color = Color(0xFFFF9F0A), modifier = Modifier.weight(1f))
                                Button(onClick = { vm.downloadMlKit() }) { Text("ดาวน์โหลดตอนนี้") }
                            }
                            else -> Text("กำลังตรวจสอบ…", color = Color.Gray)
                        }
                    }
                }
                SwitchRow("ถ้ายังไม่พร้อม ใช้ตัวแปลออนไลน์ (MyMemory) แทนชั่วคราว", s.fallbackToGoogle) { s.fallbackToGoogle = it }
            }
            TranslationEngine.MYMEMORY -> {
                OutlinedTextField(
                    value = s.myMemoryEmail,
                    onValueChange = { s.myMemoryEmail = it },
                    label = { Text("อีเมล (ไม่บังคับ เพื่อเพิ่มโควตา)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            TranslationEngine.CLAUDE -> {
                OutlinedTextField(
                    value = s.claudeApiKey,
                    onValueChange = { s.claudeApiKey = it.trim() },
                    label = { Text("Claude API Key (sk-ant-…)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = s.claudeModel,
                    onValueChange = { s.claudeModel = it.trim() },
                    label = { Text("Model") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        SectionHeader("การอ่านข้อความ (OCR)")
        SliderRow("อ่านทุก ${"%.1f".format(s.ocrInterval)} วินาที", s.ocrInterval, 0.2f..1.5f, steps = 12) {
            s.ocrInterval = (it * 10).roundToInt() / 10f
        }
        StepperRow("รอข้อความนิ่ง ${s.stableFrames} รอบก่อนแปล", s.stableFrames, 1..5) { s.stableFrames = it }
        SwitchRow("ซ่อนคำแปลเมื่อข้อความในเกมหายไป", s.hideWhenNoText) { s.hideWhenNoText = it }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { onDismiss(); vm.startNewRegion() }) { Text("เพิ่มกรอบใหม่") }
            OutlinedButton(onClick = { vm.clearRegion() }) { Text("ลบกรอบทั้งหมด") }
        }
        Note("ถ้าเกมขึ้นข้อความทีละตัวอักษรช้า ๆ แล้วแปลไม่ครบประโยค ให้เพิ่มจำนวนรอบที่รอ")

        SectionHeader("จอใหญ่ / ทีวี")
        SwitchRow("โหมดจอซับไตเติล (แสดงเฉพาะคำแปล)", s.subtitleScreenMode) { s.subtitleScreenMode = it }
        StepperRow("แสดงย้อนหลัง ${s.subtitleLines} บท", s.subtitleLines, 1..4) { s.subtitleLines = it }
        Note(
            if (vm.externalDisplayConnected) "📺 จอภายนอก: เชื่อมต่อแล้ว" else "📺 จอภายนอก: ไม่ได้เชื่อมต่อ",
            if (vm.externalDisplayConnected) Color(0xFF34C759) else Color.White.copy(alpha = 0.55f),
        )
        SectionHeader("เกี่ยวกับ")
        OutlinedButton(onClick = onAbout) { Text("เครดิต / คำปฏิเสธความรับผิด / ความเป็นส่วนตัว") }

        Note("ต่อทีวีด้วยสาย USB-C → HDMI (ผ่าน Hub ที่มีช่อง USB สำหรับ Capture Card) ทีวีจะแสดงภาพเกมเต็มจอพร้อมคำแปล Samsung: ให้เลือกโหมด \"สะท้อนหน้าจอ\" ไม่ใช่ DeX")
    }
}

// ================= คำแปลและกรอบ (โมดูลเดียว) =================

@Composable
fun RegionsDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val s = vm.settings
    val regions = s.regions
    AppDialog(
        "คำแปลและกรอบ (${regions.size} กรอบ)", onDismiss,
        extraAction = {
            TextButton(onClick = { onDismiss(); vm.startNewRegion() }) { Text("+ เพิ่มกรอบ") }
        },
    ) {
        SectionHeader("ใช้กับทุกกรอบ")
        SliderRow("ความทึบพื้นหลัง", s.opacity, 0.1f..1f) { s.opacity = it }
        SwitchRow("แสดงคำอ่าน (ญี่ปุ่น / จีน)", s.showPronunciation) { s.showPronunciation = it }
        SwitchRow("แสดงกรอบเส้นประรอบข้อความ", s.showRegionOutline) { s.showRegionOutline = it }

        if (regions.isEmpty()) {
            SectionHeader("ยังไม่มีกรอบ")
            Note("แตะ \"+ เพิ่มกรอบ\" ด้านบน แล้วลากนิ้วคลุมข้อความในเกม")
        }

        regions.forEachIndexed { index, region ->
            SectionHeader("${index + 1}. ${region.name}")

            // ตัวอย่างหน้าตาคำแปลของกรอบนี้
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF33507A), Color(0xFF6A4F8C), Color(0xFFB0653F))
                        ),
                        RoundedCornerShape(12.dp),
                    )
                    .padding(14.dp),
                contentAlignment = Alignment.Center,
            ) {
                val color = AppSettings.palette[region.colorIndex.coerceIn(0, AppSettings.palette.lastIndex)]
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (region.showOriginal) {
                        SubtitleBar("Welcome back, traveler!", region.fontSize * 0.8f, s, color = color)
                    }
                    SubtitleBar("ยินดีต้อนรับกลับมา นักเดินทาง!", region.fontSize, s, color = color)
                }
            }

            SettingRow {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = region.name,
                        onValueChange = { s.updateRegion(region.copy(name = it)) },
                        label = { Text("ชื่อกรอบ") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(12.dp))
                    Switch(
                        checked = region.enabled,
                        onCheckedChange = { s.updateRegion(region.copy(enabled = it)) },
                    )
                }
            }
            SliderRow("ขนาดตัวอักษร ${region.fontSize.toInt()}", region.fontSize, 14f..48f) {
                s.updateRegion(region.copy(fontSize = it.roundToInt().toFloat()))
            }
            SettingRow {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("สีตัวอักษร", color = Color.White, modifier = Modifier.width(110.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppSettings.palette.forEachIndexed { colorIndex, color ->
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .border(
                                        3.dp,
                                        if (region.colorIndex == colorIndex) Accent else Color.Transparent,
                                        CircleShape,
                                    )
                                    .padding(4.dp)
                                    .background(color, CircleShape)
                                    .clickable { s.updateRegion(region.copy(colorIndex = colorIndex)) }
                            )
                        }
                    }
                }
            }
            SwitchRow("แสดงข้อความต้นฉบับ", region.showOriginal) {
                s.updateRegion(region.copy(showOriginal = it))
            }
            ChoiceRow("ตำแหน่งคำแปล", OverlayPosition.entries, region.overlayPosition, { it.title }) {
                s.updateRegion(region.copy(overlayPosition = it))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { onDismiss(); vm.startEditingRegion(region.id) }) { Text("ตีกรอบนี้ใหม่") }
                OutlinedButton(onClick = {
                    regions.forEach { other ->
                        if (other.id != region.id) {
                            s.updateRegion(
                                other.copy(
                                    fontSize = region.fontSize,
                                    colorIndex = region.colorIndex,
                                    showOriginal = region.showOriginal,
                                    overlayPosition = region.overlayPosition,
                                )
                            )
                        }
                    }
                }) { Text("ใช้ค่านี้กับทุกกรอบ") }
                OutlinedButton(onClick = { vm.removeRegion(region.id) }) { Text("ลบ") }
            }
        }
    }
}

// ================= ประวัติการแปล =================

@Composable
fun HistoryDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = DialogColor,
            modifier = Modifier.fillMaxWidth(0.72f).fillMaxHeight(0.92f),
        ) {
            Column {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { vm.history.clear() }, enabled = vm.history.isNotEmpty()) { Text("ล้าง") }
                    Text("ประวัติการแปล", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    TextButton(onClick = onDismiss) { Text("เสร็จ") }
                }
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                if (vm.history.isEmpty()) {
                    Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Text("ยังไม่มีประวัติ ข้อความที่แปลแล้วจะแสดงที่นี่", color = Color.Gray)
                    }
                } else {
                    LazyColumn(Modifier.padding(horizontal = 16.dp)) {
                        items(vm.history.reversed(), key = { it.id }) { entry ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(entry.original, color = Color.White.copy(alpha = 0.55f), fontSize = 14.sp)
                                    Text(entry.translated, color = Color.White, fontSize = 17.sp)
                                }
                                IconButton(onClick = { clipboard.setText(AnnotatedString(entry.translated)) }) {
                                    Icon(Icons.Filled.ContentCopy, "คัดลอก", tint = Color(0xFFB9B2FF))
                                }
                            }
                            HorizontalDivider(color = Color.White.copy(alpha = 0.06f))
                        }
                    }
                }
            }
        }
    }
}

// ================= เกี่ยวกับ / เครดิต =================

@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    AppDialog("เกี่ยวกับ", onDismiss) {
        Text(
            "${About.APP_NAME} ${About.VERSION}",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
        )
        Text("พัฒนาโดย ${About.AUTHOR}", color = Color(0xFFB9B2FF), fontSize = 15.sp)
        Text(
            "แอปแปลข้อความบนหน้าจอจาก Capture Card แบบเรียลไทม์",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 14.sp,
        )

        SectionHeader("คำปฏิเสธความรับผิด")
        SettingRow { Text(About.disclaimer, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp) }

        SectionHeader("ความเป็นส่วนตัว")
        SettingRow { Text(About.privacy, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp) }

        SectionHeader("เครดิตและใบอนุญาตโอเพนซอร์ส")
        SettingRow { Text(About.credits, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp) }
    }
}
