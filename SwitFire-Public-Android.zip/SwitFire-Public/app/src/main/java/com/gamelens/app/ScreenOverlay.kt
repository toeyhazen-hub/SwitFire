package com.gamelens.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * ชั้นวาดทับหน้าจอสำหรับโหมดจับหน้าจอ (เกมมือถือ/แอปอื่น)
 * ใช้ View ธรรมดา ไม่ใช้ Compose เพื่อให้ทำงานใน Service ได้อย่างเรียบง่าย
 */
class ScreenOverlay(
    private val context: Context,
    private val settings: AppSettings,
    private val onAddRegion: (NormRect) -> Unit,
    private val onTogglePause: () -> Boolean,
    private val onDeleteLast: () -> Unit,
    private val onStop: () -> Unit,
) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
    private val main = Handler(Looper.getMainLooper())

    private val subtitleLayer = FrameLayout(context)
    private val bubbles = HashMap<String, LinearLayout>()
    private var controlPanel: LinearLayout? = null
    private var editView: EditView? = null

    private var screenWidth = 0
    private var screenHeight = 0

    fun show(width: Int, height: Int) {
        screenWidth = width
        screenHeight = height
        main.post {
            runCatching {
                windowManager.addView(subtitleLayer, overlayParams(touchable = false))
                addControlPanel()
            }
        }
    }

    fun hide() {
        main.post {
            runCatching { windowManager.removeView(subtitleLayer) }
            controlPanel?.let { panel -> runCatching { windowManager.removeView(panel) } }
            editView?.let { view -> runCatching { windowManager.removeView(view) } }
            controlPanel = null
            editView = null
            bubbles.clear()
            subtitleLayer.removeAllViews()
        }
    }

    // ---------- คำแปล ----------

    fun setResult(region: Region, original: String, translated: String) {
        main.post {
            val bubble = bubbles.getOrPut(region.id) {
                LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    subtitleLayer.addView(this, FrameLayout.LayoutParams(1, FrameLayout.LayoutParams.WRAP_CONTENT))
                }
            }
            bubble.removeAllViews()
            val color = paletteColor(region.colorIndex)
            if (region.showOriginal && original.isNotEmpty()) {
                bubble.addView(makeText(original, region.fontSize * 0.8f, color))
            }
            bubble.addView(makeText(translated, region.fontSize, color))
            bubble.visibility = View.VISIBLE
            positionBubble(bubble, region)
        }
    }

    fun clearResult(regionId: String) {
        main.post { bubbles[regionId]?.visibility = View.GONE }
    }

    private fun makeText(text: String, sizeSp: Float, color: Int): TextView =
        TextView(context).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(24, 12, 24, 12)
            background = GradientDrawable().apply {
                cornerRadius = 16f
                setColor(AndroidColor.argb((settings.opacity * 255).toInt(), 0, 0, 0))
            }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.bottomMargin = 8
            layoutParams = params
        }

    private fun positionBubble(bubble: LinearLayout, region: Region) {
        val left = (region.rect.x * screenWidth).toInt()
        val width = max((region.rect.w * screenWidth).toInt(), 80)
        val top = (region.rect.y * screenHeight).toInt()
        val bottom = ((region.rect.y + region.rect.h) * screenHeight).toInt()
        val params = FrameLayout.LayoutParams(width, FrameLayout.LayoutParams.WRAP_CONTENT)
        params.leftMargin = left
        params.topMargin = bottom + 8
        bubble.layoutParams = params
        bubble.post {
            val height = bubble.height
            val updated = FrameLayout.LayoutParams(width, FrameLayout.LayoutParams.WRAP_CONTENT)
            updated.leftMargin = left
            updated.topMargin = when {
                // มีที่ว่างด้านบนกรอบ → วางไว้ด้านบน
                top > height + 16 -> top - height - 8
                bottom + height + 16 < screenHeight -> bottom + 8
                else -> top
            }
            bubble.layoutParams = updated
        }
    }

    private fun paletteColor(index: Int): Int {
        val colors = intArrayOf(
            AndroidColor.rgb(255, 209, 66), AndroidColor.WHITE, AndroidColor.rgb(120, 230, 255),
            AndroidColor.rgb(140, 242, 153), AndroidColor.rgb(255, 158, 77),
            AndroidColor.rgb(255, 115, 140), AndroidColor.rgb(204, 153, 255),
        )
        return colors[index.coerceIn(0, colors.lastIndex)]
    }

    // ---------- แผงควบคุมลอย ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun addControlPanel() {
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadius = 40f
                setColor(AndroidColor.argb(230, 28, 28, 34))
            }
            setPadding(12, 8, 12, 8)
        }
        val pauseButton = makeButton("⏸")
        pauseButton.setOnClickListener {
            val paused = onTogglePause()
            pauseButton.text = if (paused) "▶" else "⏸"
        }
        val addButton = makeButton("✂ กรอบ")
        addButton.setOnClickListener { startEdit() }
        val deleteButton = makeButton("🗑")
        deleteButton.setOnClickListener { onDeleteLast() }
        val stopButton = makeButton("✕")
        stopButton.setOnClickListener { onStop() }

        panel.addView(addButton)
        panel.addView(pauseButton)
        panel.addView(deleteButton)
        panel.addView(stopButton)

        val params = overlayParams(touchable = true)
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 40
        params.y = 120
        params.width = WindowManager.LayoutParams.WRAP_CONTENT
        params.height = WindowManager.LayoutParams.WRAP_CONTENT

        // ลากย้ายตำแหน่งแผงควบคุมได้
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        panel.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) {
                        params.x = startX + dx
                        params.y = startY + dy
                        runCatching { windowManager.updateViewLayout(panel, params) }
                    }
                    false
                }
                else -> false
            }
        }

        runCatching { windowManager.addView(panel, params) }
        controlPanel = panel
    }

    private fun makeButton(label: String): Button = Button(context).apply {
        text = label
        textSize = 14f
        setTextColor(AndroidColor.WHITE)
        setPadding(18, 0, 18, 0)
        background = GradientDrawable().apply {
            cornerRadius = 30f
            setColor(AndroidColor.argb(255, 60, 60, 74))
        }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.marginEnd = 8
        layoutParams = params
    }

    // ---------- โหมดตีกรอบ ----------

    private fun startEdit() {
        if (editView != null) return
        val view = EditView(context) { rect ->
            stopEdit()
            if (rect != null) onAddRegion(rect)
        }
        runCatching { windowManager.addView(view, overlayParams(touchable = true)) }
        editView = view
    }

    private fun stopEdit() {
        editView?.let { view -> runCatching { windowManager.removeView(view) } }
        editView = null
    }

    /** ชั้นโปร่งแสงให้ผู้ใช้ลากนิ้วเลือกกรอบ */
    private inner class EditView(
        context: Context,
        val onDone: (NormRect?) -> Unit,
    ) : View(context) {
        private val paint = android.graphics.Paint().apply {
            color = AndroidColor.argb(120, 0, 0, 0)
        }
        private val borderPaint = android.graphics.Paint().apply {
            color = AndroidColor.rgb(107, 92, 245)
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = 6f
        }
        private val hintPaint = android.graphics.Paint().apply {
            color = AndroidColor.WHITE
            textSize = 42f
            textAlign = android.graphics.Paint.Align.CENTER
        }
        private var startX = 0f
        private var startY = 0f
        private var currentX = 0f
        private var currentY = 0f
        private var dragging = false

        override fun onDraw(canvas: android.graphics.Canvas) {
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            if (dragging) {
                canvas.drawRect(
                    min(startX, currentX), min(startY, currentY),
                    max(startX, currentX), max(startY, currentY), borderPaint,
                )
            } else {
                canvas.drawText("ลากนิ้วคลุมข้อความที่ต้องการแปล", width / 2f, 140f, hintPaint)
                canvas.drawText("(แตะครั้งเดียวเพื่อยกเลิก)", width / 2f, 200f, hintPaint)
            }
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x; startY = event.y
                    currentX = event.x; currentY = event.y
                    dragging = false
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    currentX = event.x; currentY = event.y
                    dragging = true
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val left = min(startX, currentX)
                    val top = min(startY, currentY)
                    val right = max(startX, currentX)
                    val bottom = max(startY, currentY)
                    if (dragging && right - left > 40 && bottom - top > 24 && width > 0 && height > 0) {
                        onDone(
                            NormRect(
                                left / width, top / height,
                                (right - left) / width, (bottom - top) / height,
                            )
                        )
                    } else {
                        onDone(null)
                    }
                }
            }
            return true
        }
    }

    private fun overlayParams(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START }
    }
}
