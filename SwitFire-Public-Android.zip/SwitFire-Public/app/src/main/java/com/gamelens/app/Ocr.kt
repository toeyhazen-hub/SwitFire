package com.gamelens.app

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import kotlin.math.max
import kotlin.math.min

/** อ่านข้อความด้วย Google ML Kit (ทำงานบนเครื่อง ไม่ต้องใช้เน็ต) */
class OcrEngine {
    private val clients = mutableMapOf<OcrScript, TextRecognizer>()

    @Synchronized
    private fun client(script: OcrScript): TextRecognizer = clients.getOrPut(script) {
        when (script) {
            OcrScript.LATIN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            OcrScript.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            OcrScript.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            OcrScript.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        }
    }

    /** OCR จากเฟรม NV21 เฉพาะในกรอบ */
    suspend fun recognizeNv21(nv21: ByteArray, width: Int, height: Int, roi: NormRect, language: GameLanguage): String {
        val cropped = cropNv21(nv21, width, height, roi) ?: return ""
        val image = InputImage.fromByteArray(
            cropped.data, cropped.width, cropped.height, 0, InputImage.IMAGE_FORMAT_NV21
        )
        return recognize(image, language)
    }

    /** OCR จากรูปภาพ (โหมดทดสอบ) */
    suspend fun recognizeBitmap(bitmap: Bitmap, roi: NormRect, language: GameLanguage): String {
        val rect = roiToRect(roi, bitmap.width, bitmap.height, even = false) ?: return ""
        val cropped = Bitmap.createBitmap(bitmap, rect.left, rect.top, rect.width(), rect.height())
        return recognize(InputImage.fromBitmap(cropped, 0), language)
    }

    /** OCR ทั้งรูป (รูปที่ตัดเฉพาะกรอบมาแล้ว) */
    suspend fun recognizeWholeBitmap(bitmap: Bitmap, language: GameLanguage): String =
        recognize(InputImage.fromBitmap(bitmap, 0), language)

    private suspend fun recognize(image: InputImage, language: GameLanguage): String {
        val script = language.ocr ?: OcrScript.LATIN
        val result: Text = client(script).process(image).await()
        val lines = result.textBlocks.flatMap { it.lines }.filter { it.boundingBox != null }
        return joinLines(lines, language)
    }

    /** เรียงบรรทัดจากบนลงล่าง แล้วซ้ายไปขวา */
    private fun joinLines(lines: List<Text.Line>, language: GameLanguage): String {
        val sorted = lines.sortedBy { it.boundingBox!!.top }
        val rows = mutableListOf<MutableList<Text.Line>>()
        for (line in sorted) {
            val box = line.boundingBox!!
            val row = rows.lastOrNull()
            val rowBox = row?.first()?.boundingBox
            if (row != null && rowBox != null &&
                kotlin.math.abs(box.centerY() - rowBox.centerY()) < min(box.height(), rowBox.height()) / 2
            ) row += line else rows += mutableListOf(line)
        }
        val separator = if (language.joinsWithoutSpaces) "" else " "
        return rows.flatMap { row -> row.sortedBy { it.boundingBox!!.left } }
            .map { it.text.trim() }
            .filter { it.isNotEmpty() }
            .joinToString(separator)
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    class Nv21(val data: ByteArray, val width: Int, val height: Int)

    private fun roiToRect(roi: NormRect, width: Int, height: Int, even: Boolean): Rect? {
        fun align(v: Int) = if (even) v and 1.inv() else v
        val x = align((roi.x * width).toInt().coerceIn(0, width - 2))
        val y = align((roi.y * height).toInt().coerceIn(0, height - 2))
        val w = align(min((roi.w * width).toInt(), width - x))
        val h = align(min((roi.h * height).toInt(), height - y))
        if (w < 16 || h < 16) return null
        return Rect(x, y, x + w, y + h)
    }

    /** ตัดภาพ NV21 เฉพาะส่วนในกรอบ (พิกัดต้องเป็นเลขคู่) */
    private fun cropNv21(src: ByteArray, width: Int, height: Int, roi: NormRect): Nv21? {
        if (src.size < width * height * 3 / 2) return null
        val r = roiToRect(roi, width, height, even = true) ?: return null
        val cw = r.width()
        val ch = r.height()
        val out = ByteArray(cw * ch * 3 / 2)
        for (row in 0 until ch) {
            System.arraycopy(src, (r.top + row) * width + r.left, out, row * cw, cw)
        }
        val uvSrc = width * height
        val uvDst = cw * ch
        for (row in 0 until ch / 2) {
            System.arraycopy(src, uvSrc + (r.top / 2 + row) * width + r.left, out, uvDst + row * cw, cw)
        }
        return Nv21(out, cw, max(ch, 2))
    }
}
