package com.gamelens.app

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import android.app.Presentation
import android.content.Context
import android.content.ContextWrapper
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.view.Display
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private lateinit var displayManager: DisplayManager
    private var presentation: TvPresentation? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) {
                vm.onForeground()
            } else {
                vm.status = "ต้องอนุญาต \"กล้อง\" เพื่อรับภาพจาก Capture Card (ตั้งค่า › แอป › GameLens › สิทธิ์)"
            }
        }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = updatePresentation()
        override fun onDisplayRemoved(displayId: Int) = updatePresentation()
        override fun onDisplayChanged(displayId: Int) = Unit
    }

    private val overlayPermissionLauncher =
        registerForActivityResult(StartActivityForResult()) { requestProjection() }

    private val projectionLauncher =
        registerForActivityResult(StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java)
                    .setAction(ScreenCaptureService.ACTION_START)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                startForegroundService(intent)
                Toast.makeText(this, "เริ่มโหมดจับหน้าจอแล้ว — เปิดเกมได้เลย", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "ยกเลิกการจับหน้าจอ", Toast.LENGTH_SHORT).show()
            }
        }

    /** เรียกจากหน้าตั้งค่า: ขอสิทธิ์วาดทับแอปอื่น แล้วขอสิทธิ์จับหน้าจอ */
    fun startScreenMode() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "เปิดสิทธิ์ \"แสดงทับแอปอื่น\" ให้ SwitFire ก่อน แล้วกดย้อนกลับมา",
                Toast.LENGTH_LONG,
            ).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"),
            )
            try {
                overlayPermissionLauncher.launch(intent)
            } catch (e: ActivityNotFoundException) {
                // บางรอม (เช่น HyperOS/MIUI) ไม่มีหน้านี้โดยตรง → เปิดหน้าข้อมูลแอปแทน
                try {
                    overlayPermissionLauncher.launch(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:$packageName"),
                        )
                    )
                } catch (e2: Exception) {
                    Toast.makeText(this, "เปิดหน้าสิทธิ์ไม่ได้ ให้ไปที่ ตั้งค่า › แอป › SwitFire › แสดงทับแอปอื่น", Toast.LENGTH_LONG).show()
                }
            }
            return
        }
        requestProjection()
    }

    fun stopScreenMode() {
        startService(
            Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP)
        )
    }

    private fun requestProjection() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "ยังไม่ได้สิทธิ์แสดงทับแอปอื่น — เปิดที่ ตั้งค่า › แอป › SwitFire › แสดงทับแอปอื่น",
                Toast.LENGTH_LONG,
            ).show()
            return
        }
        try {
            val manager = getSystemService(MediaProjectionManager::class.java)
            Toast.makeText(this, "กำลังขอสิทธิ์จับหน้าจอ…", Toast.LENGTH_SHORT).show()
            projectionLauncher.launch(manager.createScreenCaptureIntent())
        } catch (e: Exception) {
            Toast.makeText(this, "เริ่มโหมดจับหน้าจอไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        displayManager = getSystemService(DisplayManager::class.java)
        setContent { GameLensTheme { MainScreen(vm) } }
    }

    override fun onStart() {
        super.onStart()
        val hasCamera = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        val hasAudio = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (hasCamera && hasAudio) {
            vm.onForeground()
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
        displayManager.registerDisplayListener(displayListener, null)
        updatePresentation()
    }

    override fun onStop() {
        displayManager.unregisterDisplayListener(displayListener)
        presentation?.dismiss()
        presentation = null
        vm.externalDisplayConnected = false
        vm.onBackground()
        super.onStop()
    }

    /** ถ้ามีจอภายนอก (HDMI) ให้แสดงภาพเกมเต็มจอพร้อมคำแปลบนจอนั้น */
    private fun updatePresentation() {
        val display = displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull()
        if (display == null) {
            presentation?.dismiss()
            presentation = null
            vm.externalDisplayConnected = false
            return
        }
        if (presentation?.display?.displayId == display.displayId) return
        presentation?.dismiss()
        presentation = try {
            TvPresentation(this, display, vm).also { it.show() }
        } catch (e: WindowManager.InvalidDisplayException) {
            null
        }
        vm.externalDisplayConnected = presentation != null
    }
}

/** หน้าจอบนทีวี: ภาพเกมเต็มจอ + คำแปล (ไม่มีปุ่ม) */
class TvPresentation(
    private val activity: ComponentActivity,
    display: Display,
    private val vm: AppViewModel,
) : Presentation(activity, display) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(activity)
            decor.setViewTreeSavedStateRegistryOwner(activity)
            decor.setViewTreeViewModelStoreOwner(activity)
        }
        val view = ComposeView(context).apply {
            setContent { GameLensTheme { TvScreen(vm) } }
        }
        setContentView(view)
    }
}


/** หา MainActivity จาก Context (ใน Dialog ของ Compose context จะถูกห่อด้วย ContextWrapper) */
fun Context.findMainActivity(): MainActivity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is MainActivity) return current
        current = current.baseContext
    }
    return null
}
