package com.gamelens.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.PixelCopy
import android.view.SurfaceView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/** ศูนย์กลางของแอป: รับภาพ → OCR → รอข้อความนิ่ง → แปล → แสดงผล */
class AppViewModel(app: Application) : AndroidViewModel(app), UvcCapture.Listener {
    val settings = AppSettings(app)
    val capture = UvcCapture(this)
    private val audio = AudioPassthrough(app)
    private val ocr = OcrEngine()
    val mlKit = MlKitTranslate()
    private val stabilizer = TextStabilizer()
    private val cache = HashMap<String, String>()
    private var translationGeneration = 0

    // สถานะภาพ
    var status by mutableStateOf("กำลังเริ่มต้น…")
    var isLive by mutableStateOf(false)
    var contentWidth by mutableStateOf(1920)
    var contentHeight by mutableStateOf(1080)
    var testImage by mutableStateOf<Bitmap?>(null)
    var audioStatus by mutableStateOf("")
    var externalDisplayConnected by mutableStateOf(false)

    // การใช้งาน
    var isPaused by mutableStateOf(false)
    var isSelectingRegion by mutableStateOf(false)

    // ผลลัพธ์
    var originalText by mutableStateOf("")
    var pronunciation by mutableStateOf<String?>(null)
    var translatedText by mutableStateOf("")
    var isTranslating by mutableStateOf(false)
    val history = mutableStateListOf<HistoryEntry>()

    // สถานะ ML Kit
    var mlKitReady by mutableStateOf<Boolean?>(null)
    var mlKitDownloading by mutableStateOf(false)

    // OCR worker
    private val ocrBusy = AtomicBoolean(false)
    @Volatile private var lastOcrTime = 0L
    @Volatile private var forceNext = false
    @Volatile private var ocrRoi: NormRect? = null
    @Volatile private var ocrLanguage: GameLanguage = Languages.all[0]
    @Volatile private var ocrIntervalMs = 400L
    @Volatile private var ocrPaused = false

    private var started = false
    private var inBackground = false
    private var restartAttempts = 0
    private var audioJob: Job? = null
    // กันระบบเสียงพยายามต่อใหม่ถี่ ๆ (ต้นเหตุภาพกระตุกเป็นจังหวะ)
    private var audioWasRunning = false
    private var audioReconnects = 0
    private var lastAudioReconnect = 0L
    var autoRestartCount by mutableStateOf(0)
    var measuredFps by mutableStateOf(0)

    /** SurfaceView ที่แสดงภาพเกม ใช้ดึงภาพไป OCR ด้วย PixelCopy */
    @Volatile var ocrSurface: WeakReference<SurfaceView>? = null
    private val copyThread = HandlerThread("GameLens-Copy").apply { start() }
    private val copyHandler = Handler(copyThread.looper)
    private var lastMaxResolution = settings.maxResolution
    private var lastLanguageKey = ""
    private var lastAudioEnabled = settings.audioEnabled

    init {
        settings.onChange = { settingsChanged() }
        capture.maxHeight = settings.maxResolution
        stabilizer.requiredStableCount = settings.stableFrames
        audio.volume = settings.audioVolume
        lastLanguageKey = languageKey()
        pushOcrConfig()
        startWatchdog()
        startOcrLoop()
        refreshMlKitStatus()
    }

    // ---------- วงจรชีวิต ----------

    /** เรียกเมื่อแอปอยู่หน้าจอและได้สิทธิ์กล้องแล้ว */
    fun onForeground() {
        inBackground = false
        started = true
        if (testImage == null) {
            restartAttempts = 0
            capture.start()
        }
    }

    fun onBackground() {
        inBackground = true
        stopAudio()
        capture.stop()
        isLive = false
    }

    fun retryCapture() {
        restartAttempts = 0
        if (testImage == null) capture.restart()
    }

    override fun onCleared() {
        stopAudio()
        capture.stop()
        copyThread.quitSafely()
        super.onCleared()
    }

    // ---------- UvcCapture.Listener ----------

    override fun onCaptureStatus(text: String, live: Boolean) {
        status = text
        isLive = live
        if (live) {
            restartAttempts = 0
            audioWasRunning = false
            audioReconnects = 0
            scheduleAudioStart()
        } else {
            stopAudio()
        }
    }

    override fun onFrameSize(width: Int, height: Int) {
        if (testImage == null) {
            contentWidth = width
            contentHeight = height
        }
    }

    /** ตรวจทุก 1 วินาที ถ้าภาพหยุดเกิน 3 วินาทีให้เริ่มใหม่อัตโนมัติ */
    private fun startWatchdog() {
        viewModelScope.launch {
            while (isActive) {
                delay(1000)
                measuredFps = capture.takeFrameCount()
                if (!started || inBackground || testImage != null || !isLive) continue
                val silence = SystemClock.elapsedRealtime() - capture.lastFrameTime
                if (silence < 1500) {
                    // เสียงที่เคยเล่นได้แล้วหลุดไป → ต่อใหม่ แต่ไม่เกินทุก 15 วินาที และไม่เกิน 3 ครั้ง
                    val now = SystemClock.elapsedRealtime()
                    if (settings.audioEnabled && audioWasRunning && !audio.isRunning && audioJob == null &&
                        audioReconnects < 3 && now - lastAudioReconnect > 15000
                    ) {
                        audioReconnects++
                        lastAudioReconnect = now
                        scheduleAudioStart(500)
                    }
                    continue
                }
                if (silence > 4000) {
                    restartAttempts++
                    autoRestartCount++
                    if (restartAttempts > 6) {
                        isLive = false
                        status = "ไม่ได้รับภาพจาก Capture Card — ลองถอดสายแล้วเสียบใหม่ หรือแตะ เริ่มภาพใหม่"
                        continue
                    }
                    capture.useBestSize = restartAttempts % 2 == 0
                    status = "ไม่ได้รับภาพ กำลังเริ่มใหม่อัตโนมัติ…"
                    capture.restart()
                }
            }
        }
    }

    // ---------- เสียง ----------

    private fun scheduleAudioStart(delayMs: Long = 1200) {
        audioJob?.cancel()
        audioJob = viewModelScope.launch {
            delay(delayMs)
            updateAudio()
            audioJob = null
        }
    }

    private fun stopAudio() {
        audioJob?.cancel()
        audioJob = null
        audio.stop()
    }

    private suspend fun updateAudio() {
        if (!settings.audioEnabled || !isLive) {
            audio.stop()
            audioStatus = if (settings.audioEnabled) "" else "ปิดเสียงเกมอยู่"
            return
        }
        val error = withContext(Dispatchers.IO) { audio.start() }
        if (error == null) audioWasRunning = true
        audioStatus = error ?: "กำลังเล่นเสียงเกม"
    }

    // ---------- การตั้งค่า ----------

    private fun languageKey() = "${settings.sourceLangId}>${settings.targetLangId}>${settings.engine.name}"

    private fun settingsChanged() {
        pushOcrConfig()
        stabilizer.requiredStableCount = settings.stableFrames
        audio.volume = settings.audioVolume
        val key = languageKey()
        if (key != lastLanguageKey) {
            lastLanguageKey = key
            stabilizer.reset()
            clearSubtitles()
            refreshMlKitStatus()
        }
        if (settings.maxResolution != lastMaxResolution) {
            lastMaxResolution = settings.maxResolution
            capture.maxHeight = settings.maxResolution
            capture.useBestSize = true
            if (testImage == null && started) capture.restart()
        }
        if (settings.audioEnabled != lastAudioEnabled) {
            lastAudioEnabled = settings.audioEnabled
            audioReconnects = 0
            viewModelScope.launch { updateAudio() }
        }
    }

    private fun pushOcrConfig() {
        ocrRoi = if (testImage == null) settings.roi else null
        ocrLanguage = settings.sourceLanguage
        ocrIntervalMs = (settings.ocrInterval * 1000).toLong()
        ocrPaused = isPaused || isSelectingRegion
    }

    fun togglePause() {
        isPaused = !isPaused
        pushOcrConfig()
    }

    fun setSelecting(value: Boolean) {
        isSelectingRegion = value
        pushOcrConfig()
    }

    fun refreshMlKitStatus() {
        viewModelScope.launch {
            mlKitReady = if (settings.sourceLangId == settings.targetLangId) true
            else mlKit.isReady(settings.sourceLanguage, settings.targetLanguage)
        }
    }

    fun downloadMlKit() {
        if (mlKitDownloading) return
        mlKitDownloading = true
        viewModelScope.launch {
            try {
                mlKit.download(settings.sourceLanguage, settings.targetLanguage)
            } catch (e: Exception) {
                status = "ดาวน์โหลดภาษาไม่สำเร็จ: ${e.message}"
            }
            mlKitDownloading = false
            refreshMlKitStatus()
        }
    }

    // ---------- กรอบ OCR ----------

    fun setRegion(roi: NormRect) {
        settings.roi = roi
        setSelecting(false)
        stabilizer.reset()
        clearSubtitles()
        if (testImage != null) runImageOcr()
    }

    fun clearRegion() {
        settings.roi = null
        stabilizer.reset()
        clearSubtitles()
    }

    fun translateNow() {
        if (settings.roi == null) {
            status = "ตีกรอบบริเวณข้อความก่อน"
            setSelecting(true)
            return
        }
        if (testImage != null) runImageOcr() else forceNext = true
    }

    // ---------- โหมดทดสอบด้วยภาพ ----------

    fun loadTestImage(uri: Uri) {
        viewModelScope.launch {
            val bitmap = try {
                withContext(Dispatchers.IO) {
                    val source = ImageDecoder.createSource(getApplication<Application>().contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    }
                }
            } catch (e: Exception) {
                status = "เปิดรูปไม่ได้: ${e.message}"
                return@launch
            }
            stopAudio()
            capture.stop()
            isLive = false
            testImage = bitmap
            contentWidth = bitmap.width
            contentHeight = bitmap.height
            status = "โหมดทดสอบด้วยภาพ"
            pushOcrConfig()
            stabilizer.reset()
            clearSubtitles()
            if (settings.roi != null) runImageOcr()
        }
    }

    fun exitTestImage() {
        testImage = null
        clearSubtitles()
        stabilizer.reset()
        pushOcrConfig()
        restartAttempts = 0
        capture.start()
    }

    private fun runImageOcr() {
        val bitmap = testImage ?: return
        val roi = settings.roi ?: return
        val language = settings.sourceLanguage
        status = "กำลังอ่านข้อความ…"
        viewModelScope.launch {
            val text = try {
                withContext(Dispatchers.Default) { ocr.recognizeBitmap(bitmap, roi, language) }
            } catch (e: Exception) {
                ""
            }
            status = "โหมดทดสอบด้วยภาพ"
            handleText(text, forced = true)
        }
    }

    // ---------- OCR จากภาพสด ----------

    /**
     * OCR จากภาพสด: ดึงภาพเฉพาะกรอบจากหน้าจอด้วย PixelCopy เป็นระยะ ๆ
     * ไม่ต้องแปลงภาพทุกเฟรม ภาพเกมจึงลื่นเต็ม 60fps
     */
    private fun startOcrLoop() {
        viewModelScope.launch {
            while (isActive) {
                delay(50)
                if (testImage != null || !isLive || inBackground) continue
                val roi = settings.roi ?: continue
                val now = SystemClock.elapsedRealtime()
                val force = forceNext
                val interval = (settings.ocrInterval * 1000).toLong()
                if (!force && (isPaused || isSelectingRegion || now - lastOcrTime < interval)) continue
                val view = ocrSurface?.get() ?: continue
                if (!view.holder.surface.isValid || view.width < 16 || view.height < 16) continue
                forceNext = false
                lastOcrTime = now
                val text = try {
                    captureAndRecognize(view, roi, settings.sourceLanguage)
                } catch (e: Exception) {
                    null
                }
                if (text != null) handleText(text, force)
            }
        }
    }

    private suspend fun captureAndRecognize(view: SurfaceView, roi: NormRect, language: GameLanguage): String? {
        val w = view.width
        val h = view.height
        val left = (roi.x * w).toInt().coerceIn(0, w - 2)
        val top = (roi.y * h).toInt().coerceIn(0, h - 2)
        val right = ((roi.x + roi.w) * w).toInt().coerceIn(left + 1, w)
        val bottom = ((roi.y + roi.h) * h).toInt().coerceIn(top + 1, h)
        val rect = Rect(left, top, right, bottom)
        if (rect.width() < 16 || rect.height() < 16) return null
        val bitmap = Bitmap.createBitmap(rect.width(), rect.height(), Bitmap.Config.ARGB_8888)
        val ok = suspendCancellableCoroutine<Boolean> { cont ->
            PixelCopy.request(view, rect, bitmap, { result ->
                if (cont.isActive) cont.resume(result == PixelCopy.SUCCESS)
            }, copyHandler)
        }
        if (!ok) return null
        return withContext(Dispatchers.Default) { ocr.recognizeWholeBitmap(bitmap, language) }
    }

    private fun handleText(text: String, forced: Boolean) {
        if (forced) {
            if (text.isEmpty()) {
                status = "ไม่พบข้อความในกรอบ"
                return
            }
            stabilizer.markEmitted(text)
            translate(text)
            return
        }
        if (isPaused) return
        when (val event = stabilizer.feed(text)) {
            is TextStabilizer.Event.None -> Unit
            is TextStabilizer.Event.Cleared -> if (settings.hideWhenNoText) clearSubtitles()
            is TextStabilizer.Event.NewText -> translate(event.text)
        }
    }

    // ---------- แปล ----------

    private fun translate(text: String) {
        val source = settings.sourceLanguage
        val target = settings.targetLanguage
        val engine = settings.engine
        originalText = text
        pronunciation = if (settings.showPronunciation) Pronunciation.romanize(text, source) else null

        if (source.id == target.id) {
            show(text, text)
            return
        }
        val cacheKey = "${engine.name}|${source.id}|${target.id}|$text"
        cache[cacheKey]?.let {
            show(it, text)
            return
        }

        translationGeneration++
        val generation = translationGeneration
        translatedText = ""
        isTranslating = true
        val context = history.takeLast(6)

        viewModelScope.launch {
            try {
                val result = when (engine) {
                    TranslationEngine.MLKIT -> translateWithMlKit(text, source, target)
                    TranslationEngine.MYMEMORY ->
                        MyMemoryTranslate.translate(text, source, target, settings.myMemoryEmail)
                    TranslationEngine.CLAUDE -> ClaudeTranslate.translate(
                        text, source, target, settings.claudeApiKey, settings.claudeModel, context
                    )
                }
                if (cache.size > 500) cache.clear()
                cache[cacheKey] = result
                if (generation == translationGeneration) show(result, text)
            } catch (e: Exception) {
                if (generation == translationGeneration) {
                    isTranslating = false
                    translatedText = "⚠️ ${e.message ?: "แปลไม่สำเร็จ"}"
                }
            }
        }
    }

    /** ML Kit: ถ้ายังไม่ได้ดาวน์โหลดภาษา หรือช้าเกินไป ให้ใช้ตัวแปลออนไลน์แทนชั่วคราว (ถ้าเปิดไว้) */
    private suspend fun translateWithMlKit(text: String, source: GameLanguage, target: GameLanguage): String {
        val fallback = settings.fallbackToGoogle
        if (fallback && mlKitReady == false) {
            if (!mlKitDownloading) downloadMlKit()
            return MyMemoryTranslate.translate(text, source, target, settings.myMemoryEmail)
        }
        return try {
            withTimeout(8000) { mlKit.translate(text, source, target) }
        } catch (e: Exception) {
            if (!fallback) throw e
            MyMemoryTranslate.translate(text, source, target, settings.myMemoryEmail)
        }
    }

    private fun show(translation: String, original: String) {
        isTranslating = false
        translatedText = translation
        if (history.lastOrNull()?.original != original) {
            history += HistoryEntry(original, translation)
            while (history.size > 300) history.removeAt(0)
        }
    }

    private fun clearSubtitles() {
        translationGeneration++
        originalText = ""
        pronunciation = null
        translatedText = ""
        isTranslating = false
    }
}
