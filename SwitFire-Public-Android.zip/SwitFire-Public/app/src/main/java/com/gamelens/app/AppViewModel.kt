package com.gamelens.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.PixelCopy
import android.view.SurfaceView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.lang.ref.WeakReference
import kotlin.coroutines.resume

/** ศูนย์กลางของแอป: รับภาพ → OCR → รอข้อความนิ่ง → แปล → แสดงผล */
class AppViewModel(app: Application) : AndroidViewModel(app), UvcCapture.Listener {
    val settings = AppSettings(app)
    val capture = UvcCapture(this)
    private val audio = AudioPassthrough(app)
    private val ocr = OcrEngine()
    val mlKit = MlKitTranslate()
    private val cache = HashMap<String, String>()

    // สถานะภาพ
    var status by mutableStateOf("กำลังเริ่มต้น…")
    var isLive by mutableStateOf(false)
    var contentWidth by mutableStateOf(1920)
    var contentHeight by mutableStateOf(1080)
    var testImage by mutableStateOf<Bitmap?>(null)
    var audioStatus by mutableStateOf("")
    var externalDisplayConnected by mutableStateOf(false)

    // การใช้งาน
    var isPaused by mutableStateOf(false)
    var isSelectingRegion by mutableStateOf(false)

    // ผลลัพธ์ของแต่ละกรอบ
    class RegionResult {
        var original by mutableStateOf("")
        var pronunciation by mutableStateOf<String?>(null)
        var translated by mutableStateOf("")
        var isTranslating by mutableStateOf(false)
    }

    private val results = mutableStateMapOf<String, RegionResult>()

    /** ใช้ตอนวาดหน้าจอ (ไม่สร้างใหม่) */
    fun resultOrNull(id: String): RegionResult? = results[id]

    /** ใช้ตอนประมวลผล (สร้างใหม่ได้) */
    fun result(id: String): RegionResult = results[id] ?: RegionResult().also { results[id] = it }

    val history = mutableStateListOf<HistoryEntry>()

    /** กรอบที่กำลังตีใหม่ (null = เพิ่มกรอบใหม่) */
    var editingRegionId: String? = null
        private set

    private val stabilizers = HashMap<String, TextStabilizer>()
    private val lastOcrTimes = HashMap<String, Long>()
    private val translationGenerations = HashMap<String, Int>()
    private var forceAll = false

    // สถานะ ML Kit
    var mlKitReady by mutableStateOf<Boolean?>(null)
    var mlKitDownloading by mutableStateOf(false)

    // OCR worker
    @Volatile private var lastOcrTime = 0L
    @Volatile private var ocrLanguage: GameLanguage = Languages.all[0]
    @Volatile private var ocrIntervalMs = 400L
    @Volatile private var ocrPaused = false

    private var started = false
    private var inBackground = false
    private var restartAttempts = 0
    private var audioJob: Job? = null
    // กันระบบเสียงพยายามต่อใหม่ถี่ ๆ (ต้นเหตุภาพกระตุกเป็นจังหวะ)
    private var audioWasRunning = false
    private var audioReconnects = 0
    private var lastAudioReconnect = 0L
    var autoRestartCount by mutableStateOf(0)
    var measuredFps by mutableStateOf(0)
    var availableModes by mutableStateOf<List<String>>(emptyList())

    /** SurfaceView ที่แสดงภาพเกม ใช้ดึงภาพไป OCR ด้วย PixelCopy */
    @Volatile var ocrSurface: WeakReference<SurfaceView>? = null
    private val copyThread = HandlerThread("GameLens-Copy").apply { start() }
    private val copyHandler = Handler(copyThread.looper)
    private var lastMaxResolution = settings.maxResolution
    private var lastLanguageKey = ""
    private var lastAudioEnabled = settings.audioEnabled

    init {
        settings.migrateLegacyRegion()
        settings.onChange = { settingsChanged() }
        capture.maxHeight = settings.maxResolution
        capture.preferredMode = settings.preferredMode
        audio.volume = settings.audioVolume
        lastLanguageKey = languageKey()
        pushOcrConfig()
        startWatchdog()
        startOcrLoop()
        refreshMlKitStatus()
    }

    // ---------- วงจรชีวิต ----------

    /** เรียกเมื่อแอปอยู่หน้าจอและได้สิทธิ์กล้องแล้ว */
    fun onForeground() {
        inBackground = false
        started = true
        if (testImage == null) {
            restartAttempts = 0
            capture.start()
        }
    }

    fun onBackground() {
        inBackground = true
        stopAudio()
        capture.stop()
        isLive = false
    }

    fun retryCapture() {
        restartAttempts = 0
        if (testImage == null) capture.restart()
    }

    override fun onCleared() {
        stopAudio()
        capture.stop()
        copyThread.quitSafely()
        super.onCleared()
    }

    // ---------- UvcCapture.Listener ----------

    override fun onCaptureStatus(text: String, live: Boolean) {
        status = text
        isLive = live
        if (live) {
            restartAttempts = 0
            audioWasRunning = false
            audioReconnects = 0
            scheduleAudioStart()
        } else {
            stopAudio()
        }
    }

    override fun onModesAvailable(modes: List<String>) {
        availableModes = modes
    }

    override fun onFrameSize(width: Int, height: Int) {
        if (testImage == null) {
            contentWidth = width
            contentHeight = height
        }
    }

    /** ตรวจทุก 1 วินาที ถ้าภาพหยุดเกิน 3 วินาทีให้เริ่มใหม่อัตโนมัติ */
    private fun startWatchdog() {
        viewModelScope.launch {
            while (isActive) {
                delay(1000)
                measuredFps = capture.takeFrameCount()
                if (!started || inBackground || testImage != null || !isLive) continue
                val silence = SystemClock.elapsedRealtime() - capture.lastFrameTime
                if (silence < 1500) {
                    // เสียงที่เคยเล่นได้แล้วหลุดไป → ต่อใหม่ แต่ไม่เกินทุก 15 วินาที และไม่เกิน 3 ครั้ง
                    val now = SystemClock.elapsedRealtime()
                    if (settings.audioEnabled && audioWasRunning && !audio.isRunning && audioJob == null &&
                        audioReconnects < 3 && now - lastAudioReconnect > 15000
                    ) {
                        audioReconnects++
                        lastAudioReconnect = now
                        scheduleAudioStart(500)
                    }
                    continue
                }
                if (silence > 4000) {
                    restartAttempts++
                    autoRestartCount++
                    if (restartAttempts > 6) {
                        isLive = false
                        status = "ไม่ได้รับภาพจาก Capture Card — ลองถอดสายแล้วเสียบใหม่ หรือแตะ เริ่มภาพใหม่"
                        continue
                    }
                    capture.useBestSize = restartAttempts % 2 == 0
                    status = "ไม่ได้รับภาพ กำลังเริ่มใหม่อัตโนมัติ…"
                    capture.restart()
                }
            }
        }
    }

    // ---------- เสียง ----------

    private fun scheduleAudioStart(delayMs: Long = 1200) {
        audioJob?.cancel()
        audioJob = viewModelScope.launch {
            delay(delayMs)
            updateAudio()
            audioJob = null
        }
    }

    private fun stopAudio() {
        audioJob?.cancel()
        audioJob = null
        audio.stop()
    }

    private suspend fun updateAudio() {
        if (!settings.audioEnabled || !isLive) {
            audio.stop()
            audioStatus = if (settings.audioEnabled) "" else "ปิดเสียงเกมอยู่"
            return
        }
        val error = withContext(Dispatchers.IO) { audio.start() }
        if (error == null) audioWasRunning = true
        audioStatus = error ?: "กำลังเล่นเสียงเกม"
    }

    // ---------- การตั้งค่า ----------

    private fun languageKey() = "${settings.sourceLangId}>${settings.targetLangId}>${settings.engine.name}"

    private fun settingsChanged() {
        pushOcrConfig()
        audio.volume = settings.audioVolume
        val key = languageKey()
        if (key != lastLanguageKey) {
            lastLanguageKey = key
            stabilizers.clear()
            clearSubtitles()
            refreshMlKitStatus()
        }
        if (settings.preferredMode != capture.preferredMode) {
            capture.preferredMode = settings.preferredMode
            capture.useBestSize = true
            if (testImage == null && started) capture.restart()
        }
        if (settings.maxResolution != lastMaxResolution) {
            lastMaxResolution = settings.maxResolution
            capture.maxHeight = settings.maxResolution
            capture.useBestSize = true
            if (testImage == null && started) capture.restart()
        }
        if (settings.audioEnabled != lastAudioEnabled) {
            lastAudioEnabled = settings.audioEnabled
            audioReconnects = 0
            viewModelScope.launch { updateAudio() }
        }
    }

    private fun pushOcrConfig() {
        ocrLanguage = settings.sourceLanguage
        ocrIntervalMs = (settings.ocrInterval * 1000).toLong()
        ocrPaused = isPaused || isSelectingRegion
    }

    private fun stabilizer(id: String): TextStabilizer =
        stabilizers.getOrPut(id) { TextStabilizer() }.also { it.requiredStableCount = settings.stableFrames }

    fun togglePause() {
        isPaused = !isPaused
        pushOcrConfig()
    }

    fun setSelecting(value: Boolean) {
        isSelectingRegion = value
        pushOcrConfig()
    }

    fun refreshMlKitStatus() {
        viewModelScope.launch {
            mlKitReady = if (settings.sourceLangId == settings.targetLangId) true
            else mlKit.isReady(settings.sourceLanguage, settings.targetLanguage)
        }
    }

    fun downloadMlKit() {
        if (mlKitDownloading) return
        mlKitDownloading = true
        viewModelScope.launch {
            try {
                mlKit.download(settings.sourceLanguage, settings.targetLanguage)
            } catch (e: Exception) {
                status = "ดาวน์โหลดภาษาไม่สำเร็จ: ${e.message}"
            }
            mlKitDownloading = false
            refreshMlKitStatus()
        }
    }

    // ---------- กรอบ OCR ----------

    /** เริ่มตีกรอบใหม่ (เพิ่มกรอบ) */
    fun startNewRegion() {
        editingRegionId = null
        setSelecting(true)
    }

    /** ตีกรอบใหม่ให้กรอบเดิม */
    fun startEditingRegion(id: String) {
        editingRegionId = id
        setSelecting(true)
    }

    fun setRegion(rect: NormRect) {
        val editing = editingRegionId
        if (editing != null) {
            settings.regions.firstOrNull { it.id == editing }?.let {
                settings.updateRegion(it.copy(rect = rect))
            }
        } else {
            val number = settings.regions.size + 1
            settings.addRegion(
                Region(
                    name = "กรอบ $number",
                    rect = rect,
                    fontSize = settings.fontSize,
                    colorIndex = settings.colorIndex,
                    showOriginal = settings.showOriginal,
                    overlayPosition = settings.overlayPosition,
                )
            )
        }
        editingRegionId = null
        setSelecting(false)
        stabilizers.clear()
        clearSubtitles()
        if (testImage != null) runImageOcr()
    }

    fun removeRegion(id: String) {
        settings.removeRegion(id)
        stabilizers.remove(id)
        results.remove(id)
    }

    fun clearRegion() {
        settings.regions = emptyList()
        stabilizers.clear()
        clearSubtitles()
    }

    fun translateNow() {
        if (settings.regions.isEmpty()) {
            status = "ตีกรอบบริเวณข้อความก่อน"
            startNewRegion()
            return
        }
        if (testImage != null) runImageOcr() else forceAll = true
    }

    // ---------- โหมดทดสอบด้วยภาพ ----------

    fun loadTestImage(uri: Uri) {
        viewModelScope.launch {
            val bitmap = try {
                withContext(Dispatchers.IO) {
                    val source = ImageDecoder.createSource(getApplication<Application>().contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    }
                }
            } catch (e: Exception) {
                status = "เปิดรูปไม่ได้: ${e.message}"
                return@launch
            }
            stopAudio()
            capture.stop()
            isLive = false
            testImage = bitmap
            contentWidth = bitmap.width
            contentHeight = bitmap.height
            status = "โหมดทดสอบด้วยภาพ"
            pushOcrConfig()
            stabilizers.clear()
            clearSubtitles()
            if (settings.regions.isNotEmpty()) runImageOcr()
        }
    }

    fun exitTestImage() {
        testImage = null
        clearSubtitles()
        stabilizers.clear()
        pushOcrConfig()
        restartAttempts = 0
        capture.start()
    }

    private fun runImageOcr() {
        val bitmap = testImage ?: return
        val language = settings.sourceLanguage
        val regions = settings.regions.filter { it.enabled }
        if (regions.isEmpty()) return
        status = "กำลังอ่านข้อความ…"
        viewModelScope.launch {
            for (region in regions) {
                val text = try {
                    withContext(Dispatchers.Default) { ocr.recognizeBitmap(bitmap, region.rect, language) }
                } catch (e: Exception) {
                    ""
                }
                handleText(region, text, forced = true)
            }
            status = "โหมดทดสอบด้วยภาพ"
        }
    }

    // ---------- OCR จากภาพสด ----------

    /**
     * OCR จากภาพสด: ดึงภาพเฉพาะกรอบจากหน้าจอด้วย PixelCopy เป็นระยะ ๆ
     * ไม่ต้องแปลงภาพทุกเฟรม ภาพเกมจึงลื่นเต็ม 60fps
     */
    private fun startOcrLoop() {
        viewModelScope.launch {
            while (isActive) {
                delay(50)
                if (testImage != null || !isLive || inBackground) continue
                val view = ocrSurface?.get() ?: continue
                if (!view.holder.surface.isValid || view.width < 16 || view.height < 16) continue
                val regions = settings.regions.filter { it.enabled }
                if (regions.isEmpty()) continue

                val force = forceAll
                forceAll = false
                val interval = (settings.ocrInterval * 1000).toLong()
                for (region in regions) {
                    val now = SystemClock.elapsedRealtime()
                    val last = lastOcrTimes[region.id] ?: 0L
                    if (!force && (isPaused || isSelectingRegion || now - last < interval)) continue
                    lastOcrTimes[region.id] = now
                    val text = try {
                        captureAndRecognize(view, region.rect, settings.sourceLanguage)
                    } catch (e: Exception) {
                        null
                    }
                    if (text != null) handleText(region, text, force)
                }
            }
        }
    }

    private suspend fun captureAndRecognize(view: SurfaceView, roi: NormRect, language: GameLanguage): String? {
        val w = view.width
        val h = view.height
        val left = (roi.x * w).toInt().coerceIn(0, w - 2)
        val top = (roi.y * h).toInt().coerceIn(0, h - 2)
        val right = ((roi.x + roi.w) * w).toInt().coerceIn(left + 1, w)
        val bottom = ((roi.y + roi.h) * h).toInt().coerceIn(top + 1, h)
        val rect = Rect(left, top, right, bottom)
        if (rect.width() < 16 || rect.height() < 16) return null
        val bitmap = Bitmap.createBitmap(rect.width(), rect.height(), Bitmap.Config.ARGB_8888)
        val ok = suspendCancellableCoroutine<Boolean> { cont ->
            PixelCopy.request(view, rect, bitmap, { result ->
                if (cont.isActive) cont.resume(result == PixelCopy.SUCCESS)
            }, copyHandler)
        }
        if (!ok) return null
        return withContext(Dispatchers.Default) { ocr.recognizeWholeBitmap(bitmap, language) }
    }

    private fun handleText(region: Region, text: String, forced: Boolean) {
        val state = result(region.id)
        if (forced) {
            if (text.isEmpty()) {
                status = "ไม่พบข้อความในกรอบ ${region.name}"
                return
            }
            stabilizer(region.id).markEmitted(text)
            translate(region, text)
            return
        }
        if (isPaused) return
        when (val event = stabilizer(region.id).feed(text)) {
            is TextStabilizer.Event.None -> Unit
            is TextStabilizer.Event.Cleared -> if (settings.hideWhenNoText) clearRegionResult(state)
            is TextStabilizer.Event.NewText -> translate(region, event.text)
        }
    }

    // ---------- แปล ----------

    private fun translate(region: Region, text: String) {
        val source = settings.sourceLanguage
        val target = settings.targetLanguage
        val engine = settings.engine
        val state = result(region.id)
        state.original = text
        state.pronunciation = if (settings.showPronunciation) Pronunciation.romanize(text, source) else null

        if (source.id == target.id) {
            show(region, state, text, text)
            return
        }
        val cacheKey = "${engine.name}|${source.id}|${target.id}|$text"
        cache[cacheKey]?.let {
            show(region, state, it, text)
            return
        }

        val generation = (translationGenerations[region.id] ?: 0) + 1
        translationGenerations[region.id] = generation
        state.translated = ""
        state.isTranslating = true
        val context = history.takeLast(6)

        viewModelScope.launch {
            try {
                val result = when (engine) {
                    TranslationEngine.MLKIT -> translateWithMlKit(text, source, target)
                    TranslationEngine.MYMEMORY ->
                        MyMemoryTranslate.translate(text, source, target, settings.myMemoryEmail)
                    TranslationEngine.CLAUDE -> ClaudeTranslate.translate(
                        text, source, target, settings.claudeApiKey, settings.claudeModel, context
                    )
                }
                if (cache.size > 500) cache.clear()
                cache[cacheKey] = result
                if (generation == translationGenerations[region.id]) show(region, state, result, text)
            } catch (e: Exception) {
                if (generation == translationGenerations[region.id]) {
                    state.isTranslating = false
                    state.translated = "⚠️ ${e.message ?: "แปลไม่สำเร็จ"}"
                }
            }
        }
    }

    /** ML Kit: ถ้ายังไม่ได้ดาวน์โหลดภาษา หรือช้าเกินไป ให้ใช้ตัวแปลออนไลน์แทนชั่วคราว (ถ้าเปิดไว้) */
    private suspend fun translateWithMlKit(text: String, source: GameLanguage, target: GameLanguage): String {
        val fallback = settings.fallbackToGoogle
        if (fallback && mlKitReady == false) {
            if (!mlKitDownloading) downloadMlKit()
            return MyMemoryTranslate.translate(text, source, target, settings.myMemoryEmail)
        }
        return try {
            withTimeout(8000) { mlKit.translate(text, source, target) }
        } catch (e: Exception) {
            if (!fallback) throw e
            MyMemoryTranslate.translate(text, source, target, settings.myMemoryEmail)
        }
    }

    private fun show(region: Region, state: RegionResult, translation: String, original: String) {
        state.isTranslating = false
        state.translated = translation
        if (history.lastOrNull()?.original != original) {
            history += HistoryEntry(original, translation, region.name)
            while (history.size > 300) history.removeAt(0)
        }
    }

    private fun clearRegionResult(state: RegionResult) {
        state.original = ""
        state.pronunciation = null
        state.translated = ""
        state.isTranslating = false
    }

    private fun clearSubtitles() {
        results.values.forEach { clearRegionResult(it) }
    }

}
