plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.gamelens.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.meawdum.switfire"
        minSdk = 29
        targetSdk = 35
        versionCode = 11
        versionName = "3.0.1"
        ndk {
            // แท็บเล็ตสมัยใหม่ใช้ arm64 ทั้งหมด ตัดสถาปัตยกรรมอื่นออกให้ไฟล์เล็กลง
            abiFilters += listOf("arm64-v8a")
        }
    }

    // คีย์สำหรับเซ็นแอป (ใช้คีย์เดิมทุกครั้ง จึงอัปเดตแอปทับของเดิมได้โดยไม่ต้องลบ)
    // ถ้าจะเผยแพร่ต่อสาธารณะ ควรสร้างคีย์ใหม่ของตัวเองและเก็บรหัสเป็นความลับ
    signingConfigs {
        create("gamelens") {
            storeFile = file("gamelens.keystore")
            storePassword = "gamelens123"
            keyAlias = "gamelens"
            keyPassword = "gamelens123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("gamelens")
        }
        debug {
            signingConfig = signingConfigs.getByName("gamelens")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")

    // รับภาพจาก Capture Card (UVC) ผ่าน USB-C
    implementation("com.herohan:UVCAndroid:1.0.13")

    // OCR บนเครื่อง (Google ML Kit)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")

    // แปลภาษาบนเครื่อง ฟรี ออฟไลน์ (รองรับภาษาไทย)
    implementation("com.google.mlkit:translate:17.0.3")
}
